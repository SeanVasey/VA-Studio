#!/usr/bin/env bash
R=/tmp/claude-0/-home-user-VA-Studio/b5dc44df-c06e-5677-8541-57d7464f9ccc/scratchpad/t1-run.sh
$R m04-mysql-index-subset mysql --filter '/(sentinel with data set "twenty-one sentinel"|bytes with data set "transplanted ciphertext"|list_bytes with data set "(final fence|commit callback)")/' tests/Feature/PaidTaxHistoryIndexTest.php
$R m05-mysql-journey-subset mysql --filter '/(test_history_index_lists_only_current_owner_batches_and_refuses_late_withdrawal_before_bytes|test_late_current_owner_withdrawal_rolls_back_origin_and_allows_a_fresh_authorized_retry)/' tests/Feature/PaidTaxGrantJourneyTest.php
echo BOUNDED-DONE
