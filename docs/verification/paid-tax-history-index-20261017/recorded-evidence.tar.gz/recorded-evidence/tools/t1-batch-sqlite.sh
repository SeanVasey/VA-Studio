#!/usr/bin/env bash
R=/tmp/claude-0/-home-user-VA-Studio/b5dc44df-c06e-5677-8541-57d7464f9ccc/scratchpad/t1-run.sh
$R e01-sqlite-index sqlite tests/Feature/PaidTaxHistoryIndexTest.php
$R e02-sqlite-root-boundary sqlite tests/Feature/PaidTaxRootHttpBoundaryTest.php
$R e03-sqlite-http-journey sqlite tests/Feature/PaidTaxHttpJourneyTest.php
$R e04-sqlite-grant-journey sqlite tests/Feature/PaidTaxGrantJourneyTest.php
$R e05-sqlite-adversarial-download sqlite tests/Feature/PaidTaxAdversarialJourneyTest.php tests/Feature/PaidTaxDownloadJourneyTest.php
$R e06-sqlite-checkout-return sqlite tests/Feature/CheckoutReturnPresentationTest.php
echo BATCH-DONE
