#!/usr/bin/env bash
# usage: t1-run.sh <label> <driver: sqlite|mysql> <test files...>
set -u
label=$1; driver=$2; shift 2
out=/tmp/claude-0/-home-user-VA-Studio/b5dc44df-c06e-5677-8541-57d7464f9ccc/scratchpad/t1-evidence/$label
mkdir -p "$out"
cd /home/user/wt/t1
{
  echo "label=$label driver=$driver"
  echo "date=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "head=$(git rev-parse HEAD)"
  echo "status:"; git status --porcelain=v1
  echo "worktree_diff_sha256=$(git diff HEAD | sha256sum | cut -d' ' -f1)"
  echo "untracked_sha256=$(git ls-files --others --exclude-standard -z | xargs -0 -r sha256sum | sha256sum | cut -d' ' -f1)"
  echo "files=$*"
} > "$out/meta.txt"
if [ "$driver" = sqlite ]; then
  envs=(APP_ENV=testing APP_DEBUG=false DB_CONNECTION=sqlite DB_DATABASE=:memory: DB_URL= DB_SOCKET= CACHE_STORE=array SESSION_DRIVER=array QUEUE_CONNECTION=sync)
else
  envs=(APP_ENV=testing APP_DEBUG=false DB_CONNECTION=mysql DB_HOST=127.0.0.1 DB_PORT=33587 DB_USERNAME=root DB_PASSWORD= DB_DATABASE=vaseyaudio_catalog_import VA_LOCAL_DISPOSABLE_MYSQL=vaseyaudio_catalog_import DB_URL= DB_SOCKET= CACHE_STORE=array SESSION_DRIVER=array QUEUE_CONNECTION=sync)
fi
echo "command=env ${envs[*]} php -d memory_limit=512M -r '\$GLOBALS[\"_composer_autoload_path\"]=getcwd().\"/vendor/autoload.php\"; require \"vendor/phpunit/phpunit/phpunit\";' -- --log-junit $out/junit.xml $*" >> "$out/meta.txt"
env "${envs[@]}" php -d memory_limit=512M -r '$GLOBALS["_composer_autoload_path"]=getcwd()."/vendor/autoload.php"; require "vendor/phpunit/phpunit/phpunit";' -- --log-junit "$out/junit.xml" "$@" > "$out/stdout.txt" 2>&1
code=$?
echo "php_exit=$code" >> "$out/meta.txt"
tail -n 40 "$out/stdout.txt"
echo "php_exit=$code"
