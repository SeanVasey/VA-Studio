from pathlib import Path
import datetime,json,os
out=Path(__file__).resolve().parent
summary=[]
for launch_path in sorted(out.glob('launch-*.json')):
 launch=json.loads(launch_path.read_text());name=launch_path.stem.removeprefix('launch-');result_path=out/name/'result.json'
 if not result_path.exists():
  summary.append({'name':name,'state':'running-or-incomplete'});continue
 result=json.loads(result_path.read_text());proc=Path('/proc')/str(launch['pid'])
 fields=(proc/'stat').read_text().rsplit(')',1)[1].split()
 uids=[int(v) for l in (proc/'status').read_text().splitlines() if l.startswith('Uid:') for v in l.split()[1:]]
 assert fields[19]==launch['process_start_ticks'] and all(v==launch['uid'] for v in uids)
 if fields[0]!='Z':
  summary.append({'name':name,'state':fields[0]});continue
 status=int(fields[49]);exit_code=os.waitstatus_to_exitcode(status)
 assert exit_code==result['verifier_exit']
 record={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':launch['pid'],'start_ticks':fields[19],'state':fields[0],'process_uids':uids,'raw_wait_status':status,'exit':exit_code}
 destination=out/('observed-os-exit-'+name+'.json')
 if destination.exists():
  prior=json.loads(destination.read_text());assert all(prior[k]==record[k] for k in ['pid','start_ticks','state','process_uids','raw_wait_status','exit'])
 else:
  with destination.open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
 summary.append({'name':name,'php':result['process_exit'],'recorder':result['verifier_exit'],'os':exit_code,'junit':result['junit'],'source_unchanged':result['source_unchanged']})
print(json.dumps(summary,indent=2))
