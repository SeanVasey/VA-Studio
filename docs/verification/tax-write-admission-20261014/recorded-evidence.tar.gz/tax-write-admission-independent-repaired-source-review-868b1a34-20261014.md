# Independent Tax255 repaired-source checkpoint

DECISION: PARTIAL — the c265 P2 source repairs are accepted; this is not final development-merge/evidence approval.
Reviewed exact clean source: `868b1a34c99cd5734333732b0e58790b9f396eb6`.
Comparison: immutable `c2652593027d2d8159cc0b5e8018fffeb5c7700a`, governed by the original independent phase/design review.
No open P0/P1 or further P2 source finding is established by this bounded review. Existing canonical-guard, physical-frame, SQL/host and historical/provider boundaries remain unchanged. Final executable evidence is incomplete.

The c265 review remains immutable at `/workspace/runtime/tax-write-admission-independent-source-review-c2652593-20261014.md`, SHA256 `057e0d3aa1a677fc346343ff09e91e3506c3486d0bcf572038442a6c5482fbe1`. This checkpoint updates its source-repair and reproduction status without rewriting that note.

## Source closure

- `TaxCheckoutWriteAdmission.php:57-61` authenticates the retained request/provider-expiry tuple instead of imposing the retrospective creation-latest wall deadline. TaxCheckoutEvidence::intent already recomputes that tuple from the immutable request created_at and order context. The existing inclusive request birth rule and original timestamps remain intact; real order, retry and selected live-license bounds still cap the original 300-second frame.
- Lines 108-116 re-read and authenticate owner_key against both the verified account owner digest and immutable origin. Final raw comparison projects id/public_id/user_id/owner_key, and closes the account-origin selector. It retains id-only User existence and historical verification prefix/challenges. Present credentials, active/access_version, catalog and historical expiry are not added to paid-evidence retention.
- Lines 140-157 add request idempotency, binding global session, and reviewed binding/order/global session/payment scopes with authenticated expected rows. At most one request is established before family(), so reviewedForOrder cannot silently drop a second valid request's reviewed set. Factory decryption/authentication precedes final closure; terminal proof stays raw-PDO/metadata/config/frame only.
- Lines 164-168 capture native monotonic time before Carbon parse/now and min-cap the original frame. Carbon authority is not read at physical commit. These checks do not interrupt a blocking SQL statement.
- `ProductionTaxCheckout.php:180-182,195` captures and validates transport identity before authoritative GETs and passes that retained string to financial retention. The new test explicitly changes the transport identity after retrieve and expects the original admitted value. Both identity calls are before I/O, rather than renewing identity after the response.
- Records, FreshTax policy and raw-plan helpers are unchanged from c265. Their pre-DML storage guard and callback-free final comparison retain the earlier review's limits. Frozen V1/schema/migrations/contracts/profile/root flags/routes remain outside the delta.

## Evidence independently inspected

The original completed configuration receipts remain overlapping 1/14 and 4/60 at c265, not five unique cases. The following additional completed receipts were read, not executed by this reviewer:

| Receipt | Exact source head | Tests/assertions | Failure/error/skip | PHP/result/verifier |
| --- | --- | --- | --- | --- |
| sqlite-binding-owner-before-review-repair-transactional-guard | 52d637ed170eb7657848b716aa3b11399130ef3f | 1/4 | 1/0/0 | 1/1/1 |
| sqlite-reviewed-owner-before-review-repair-transactional-guard | 52d637ed170eb7657848b716aa3b11399130ef3f | 1/3 | 1/0/0 | 1/1/1 |
| sqlite-boundary-before-review-repair-corrected | 88649ca2de3de38e08344b71092e203eeed35f08 | 1/2 | 1/0/0 | 1/1/1 |
| sqlite-owner-and-boundary-after-review-repair-correct-status | 335c1d46a114f12853d2b2ed58ff9b45ce05b18a | 3/30 | 0/0/0 | 0/0/0 |

All five application blob byte sequences at both old-source heads equal c265. JUnit failure text shows actual target binding/reviewed growth from zero to one in the declared same-frame SQLite guard-replacement cases; the corrected birth-boundary failure is actual request count zero instead of one. These are acceptance/compatibility failures, rather than API TypeErrors. The owner tests temporarily remove then restore identical guard text inside a physical SQLite transaction. They do not prove native guard bypass or rollback across MySQL implicit DDL.

All five application byte sequences at the successful 335 checkpoint equal 868. The repaired 3/30 receipt names both owner phases and inclusive request birth, records all 2,344 actual inputs and clean/stable head/status/source/runner/autoload gates, and has recorded process marker/result/verifier zero with matching log SHA256. The old failures and repaired pass log hashes/exit markers were checked. Original guard-blocked/pre-operation-schema-rejected fixtures, assertion-signature error and repaired expected-status mismatch are retained separately; none should be reclassified as an application acceptance reproduction. No supervisor OS-exit witness is independently reconciled in this bounded checkpoint.

The source of the newly added current credential/catalog cases, historical password survival, late paid_exception, admitted transport identity and native damaged-engine cases is meaningful. Native damage changes the reviewed table to MyISAM outside the app frame, verifies actual structured ENGINE, includes a misleading InnoDB comment, and checks all four NEW write phases for refusal and unchanged original rows/wait value/idle transaction. It is a damaged-owned-storage fixture, not healthy native concurrency or general restored-schema acceptance. Active native execution and broader SQLite results were not treated as completed evidence.

## Remaining conditions and qualifications

1. Complete the affected SQLite and focused native evidence against a final immutable candidate, retaining exact commands/counts/markers and source/runner/loader/route stability; final packet review remains separate. One native-only skip-registry method pair was added exactly. That allowance is not an executed skipped-case count.
2. Exercise a genuinely elapsed original current-phase temporal cap at a normal TransactionCommitting delegate, after source admission, with rollback/idle frame/refused afterCommit cleanup and positive fresh retry. Advancing only Carbon test-now does not exercise the terminal monotonic cap. The author has agreed to use an authored synthetic license cutoff and real elapsed callback time, without extending the expired license.
3. Complete the remaining public-id lookup scopes for consistency with actual request resolution and exposed family ids. This is low-severity proof completeness, not an additional ordinary-schema P2 defect: healthy public unique constraints block ambiguity, and the request insert guard forces idempotency_key = prefix + public_id, so the new global idempotency plan already detects an ordinary same-public-id request duplicate even if the public unique index alone is removed. Any counterexample using different idempotency must declare combined guard/index replacement; do not claim index damage alone defeats this repaired proof. The author agreed to close these scopes and add bounded unrelated-request global session/payment regressions with explicit transactional SQLite guard/index fixture conditions.

No paid-delivery terminal consumer, committed Tax255 V2 wiring, existing-request pre-create final-I/O admission, live/host/provider/release/full-suite acceptance, metadata-trigger inventory or arbitrary implicit-commit compensation is approved. Preserving observed late payment and original prior retained rows remains required. Ordinary ReservationOperations post-physical-commit callback behavior is adjacent unchanged history, not closed by this batch.

Read-only Git/source/receipt/XML/hash inspection only. No application, DB, test, CI, hosted, publication or source edit was performed. This runtime note is the only additional authored artifact for this checkpoint.
