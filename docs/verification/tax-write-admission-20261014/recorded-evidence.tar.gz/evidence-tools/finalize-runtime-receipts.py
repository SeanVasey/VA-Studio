#!/usr/bin/env python3
"""Run only after every original recorder closes; preserve exact original exits."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('/workspace/VA-Studio-tax-write-admission')
r=Path('/workspace/runtime/tax-write-admission-evidence-20261014')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def new(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
launches=sorted(r.glob('launch-*.json'))
assert launches
for p in launches:assert (r/p.stem[7:]/'result.json').is_file(), 'Still active: '+p.name
for name in ('mysql-tax-write-current-raw-proof-fixed','mysql-tax-write-commit-and-history-current-raw-proof','sqlite-tax-write-affected-current-raw-proof'):
 x=read(r/name/'result.json')
 assert x['process_exit']==x['verifier_exit']==0 and x['junit']['failures']==x['junit']['errors']==0
 assert all(x[k] for k in ('source_unchanged','source_head_unchanged','source_status_unchanged','autoload_unchanged','runner_unchanged'))
witnesses=[]
for p in launches:
 launch=read(p);name=p.stem[7:];x=read(r/name/'result.json');pid=launch['pid'];proc=Path('/proc')/str(pid)
 parts=(proc/'stat').read_text().rsplit(')',1)[1].split()
 deadline=time.monotonic()+5
 while parts[0]!='Z' and time.monotonic()<deadline:
  time.sleep(0.1)
  parts=(proc/'stat').read_text().rsplit(')',1)[1].split()
 uid=int(next(s for s in (proc/'status').read_text().splitlines() if s.startswith('Uid:')).split()[1])
 identity_matches=parts[19]==str(launch['process_start_ticks']) and uid==launch['uid']
 assert identity_matches and parts[0]=='Z',name
 observed=os.waitstatus_to_exitcode(int(parts[49]));assert observed==x['verifier_exit'],name
 witnesses.append({'name':name,'recorded_utc':now(),'pid':pid,'start_ticks':parts[19],'uid':uid,'state':parts[0],'identity_matches':identity_matches,'kernel_exit_code':int(parts[49]),'observed_recorder_exit':observed,'recorded_verifier_exit':x['verifier_exit']})
new(r/'recorder-os-exit-observations-final.json',witnesses)
normal=read(r/'database-census-normal-proxy-repaired.json');assert normal['process_exit']==0
folder=r/'census-normal-proxy-outputs';folder.mkdir(exist_ok=False);cleaned=[]
for name,expected in normal['outputs'].items():
 p=root/name;assert sha(p)==expected,name;target=folder/name
 with target.open('xb') as f:f.write(p.read_bytes())
 assert sha(target)==expected and sha(p)==expected;p.unlink();cleaned.append({'name':name,'sha256':expected})
new(r/'census-normal-proxy-output-cleanup.json',{'recorded_utc':now(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'exact_hash_archived_and_removed':cleaned,'scope':'Only six owned ignored outputs from the successful original repository discovery CLI; no database tests executed by this command.'})
argv=['docker','stop','--timeout','10','va-studio-private-mysql-tax-write-20261014']
completed=subprocess.run(argv,text=True,capture_output=True)
new(r/'mysql-server-stop.json',{'recorded_utc':now(),'argv':argv,'process_exit':completed.returncode,'stdout':completed.stdout,'stderr':completed.stderr,'scope':'Only this task’s private server stopped after all native checks; named datadir retained; older private servers untouched.'})
assert completed.returncode==0
print(json.dumps({'closed_invocations':len(witnesses),'actual_recorder_OS_exits_reconciled':True,'normal_census_outputs_archived_and_cleaned':len(cleaned),'owned_MySQL_stop_exit':completed.returncode}))
