#!/usr/bin/env python3
"""Local bootstrap adapter only: retain the repository's discovery/partition proof."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/workspace/VA-Studio-tax-write-admission')
runtime = Path('/workspace/runtime/tax-write-admission-evidence-20261014')
script = root / 'scripts/ci/phpunit-shards.py'
spec = importlib.util.spec_from_file_location('tax_write_census', script)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
calls = []

def own_discover(config, output, project):
    assert project == root
    phpunit = ['phpunit', '--configuration', str(config), '--list-tests-xml', str(output)]
    code = 'require "vendor/autoload.php"; exit((new PHPUnit\\TextUI\\Application)->run(json_decode($argv[1], true, 32, JSON_THROW_ON_ERROR)));'
    argv = ['php', '-d', 'memory_limit=512M', '-r', code, json.dumps(phpunit)]
    completed = subprocess.run(argv, cwd=project, text=True, capture_output=True)
    calls.append({'argv': argv, 'cwd': str(project), 'process_exit': completed.returncode,
                  'stdout': completed.stdout, 'stderr': completed.stderr,
                  'xml_sha256': hashlib.sha256(output.read_bytes()).hexdigest() if output.is_file() else None})
    if completed.returncode:
        raise module.PartitionError('Own-worktree PHPUnit discovery failed.')
    # The repository's original XML parser, inventory validation and partition logic remain.
    return module.read_inventory(output, project)

assert not list(root.glob('phpunit-ci-mysql-*')), 'Refuse preexisting outputs.'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=root) == b''
source = hashlib.sha256(script.read_bytes()).hexdigest()
loaders = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
           for p in [root / 'vendor/autoload.php', *sorted((root / 'vendor/composer').glob('*'))] if p.is_file()}
module.discover = own_discover
sys.argv = [str(script), '--shards=2', '--prefix=phpunit-ci-mysql', '--mysql-native-selection']
error = None
exit_code = 0
try:
    module.main()
except Exception as exc:
    exit_code = 1
    error = type(exc).__name__ + ': ' + str(exc)
result = {'head': head, 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'argv': sys.argv, 'adapter_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'policy_script_sha256': source, 'process_exit': exit_code, 'error': error,
          'discovery_calls': calls,
          'policy_script_unchanged': hashlib.sha256(script.read_bytes()).hexdigest() == source,
          'loaders_unchanged': loaders == {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in loaders},
          'head_unchanged': head == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
          'status_clean': subprocess.check_output(['git', 'status', '--porcelain'], cwd=root) == b'',
          'scope': 'List-only PHPUnit discovery and original repository XML parser/selection/partition proof. Local bootstrap adaptation avoids the shared Composer bin proxy; no executed database matrix or policy change.'}
manifest = root / 'phpunit-ci-mysql-manifest.json'
if manifest.is_file():
    result['manifest'] = json.loads(manifest.read_text())
result['outputs'] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.glob('phpunit-ci-mysql-*'))}
with (runtime / 'database-census-own-autoload-list-only.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({k: result[k] for k in ('head', 'process_exit', 'error', 'policy_script_unchanged',
                                       'loaders_unchanged', 'head_unchanged', 'status_clean')}, indent=2))
if 'manifest' in result:
    print(json.dumps({k: result['manifest'][k] for k in ('source_files', 'source_test_cases', 'selection')}, indent=2))
raise SystemExit(exit_code)
