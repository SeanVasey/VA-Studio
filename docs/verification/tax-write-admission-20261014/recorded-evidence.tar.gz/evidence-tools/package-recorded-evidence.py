#!/usr/bin/env python3
"""Seal original Tax255 write receipts, including failed oracles and fixture mistakes."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import xml.etree.ElementTree as ET

root = Path('/workspace/VA-Studio-tax-write-admission')
runtime = Path('/workspace/runtime/tax-write-admission-evidence-20261014')
packet = root / 'docs/verification/tax-write-admission-20261014'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

assert not git('status', '--porcelain'), 'Freeze candidate before sealing.'
members = {}
source_blobs = {}

def include(path, name=None):
    relative = name or str(path.relative_to(runtime))
    assert relative not in members, relative
    members[relative] = path.read_bytes()

def git_inputs(head, manifest):
    found = {}
    proc = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=root,
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    try:
        for name, expected in manifest.items():
            proc.stdin.write((head + ':' + name + '\n').encode())
            proc.stdin.flush()
            header = proc.stdout.readline().split()
            assert len(header) == 3 and header[1] == b'blob', (head, name)
            size = int(header[2])
            data = proc.stdout.read(size)
            assert len(data) == size and proc.stdout.read(1) == b'\n'
            digest = sha(data)
            assert digest == expected, (head, name)
            found[name] = digest
            if digest in source_blobs:
                assert source_blobs[digest] == data
            else:
                source_blobs[digest] = data
    finally:
        proc.stdin.close()
        assert proc.wait() == 0
    return found

intended_oracles = {
    'sqlite-new-order-config-old-source',
    'sqlite-new-request-config-old-source',
    'sqlite-new-binding-config-old-source',
    'sqlite-new-reviewed-config-old-source',
    'sqlite-binding-owner-before-review-repair-transactional-guard',
    'sqlite-reviewed-owner-before-review-repair-transactional-guard',
    'sqlite-boundary-before-review-repair-corrected',
    'mysql-tax-write-global-snapshot-old-raw-source',
    'mysql-tax-write-row-wait-old-raw-source',
}
fixture_failures = {
    'sqlite-owner-and-boundary-before-review-repair': 'Intact owner guard rejected the mutation with PDO error.',
    'sqlite-owner-before-review-repair-restored-fixture': 'Removed guard refused at identity admission before the callback; not an application-gap oracle.',
    'sqlite-reviewed-owner-before-review-repair': 'Removed guard refused at identity admission before the callback; not an application-gap oracle.',
    'sqlite-boundary-before-review-repair': 'Wrong assertion signature treated the message as a database connection.',
    'sqlite-owner-and-boundary-after-review-repair': 'Expected 503 instead of established raw-source conflict 409.',
    'mysql-tax-write-damaged-engine': 'Expected 503 instead of structured-schema conflict 409; later assertions were not executed.',
    'sqlite-tax-write-live-license-cap': 'Expiry/rollback checks reached; retry fixture tried to enroll the same email again and SMTP received no notice.',
}
invocations = []
bundles = set()
launches = sorted(runtime.glob('launch-*.json'))
assert launches, 'No recorded invocations.'
os_records = read(runtime / 'recorder-os-exit-observations-final.json')
for launch_file in launches:
    launch = read(launch_file)
    name = launch_file.name.removeprefix('launch-').removesuffix('.json')
    run = runtime / name
    assert (run / 'result.json').is_file(), 'Active/incomplete invocation: ' + name
    command, result = read(run / 'command.json'), read(run / 'result.json')
    assert int((run / 'process.exit').read_text()) == result['process_exit']
    assert all(result[k] for k in ('source_unchanged', 'source_head_unchanged', 'source_status_unchanged',
                                  'runner_unchanged', 'autoload_unchanged'))
    assert launch['source'] == command['source_before'] == result['source_after']
    assert command['before_git_equal'] and command['overlays'] == []
    assert result['log_sha256'] == sha((run / 'log.txt').read_bytes())
    document = ET.parse(run / 'junit.xml').getroot()
    top = document if document.tag == 'testsuite' else document.find('testsuite')
    cases = list(document.iter('testcase'))
    counts = {'tests': len(cases), 'assertions': sum(int(c.get('assertions', '0')) for c in cases),
              'errors': sum(c.find('error') is not None for c in cases),
              'failures': sum(c.find('failure') is not None for c in cases),
              'skipped': sum(c.find('skipped') is not None for c in cases)}
    assert counts == result['junit'] == {k: int(top.get(k)) for k in counts}
    if name in intended_oracles:
        assert result['process_exit'] == result['verifier_exit'] == 1
        assert counts['failures'] == 1 and counts['errors'] == counts['skipped'] == 0
        scope = 'Original application-gap oracle; assertions after the first failure were not executed.'
    elif name in fixture_failures:
        assert result['process_exit'] != 0 and result['verifier_exit'] == 1
        assert counts['failures'] + counts['errors'] > 0
        scope = fixture_failures[name]
    else:
        assert result['process_exit'] == result['verifier_exit'] == 0
        assert counts['failures'] == counts['errors'] == 0
        scope = 'Completed focused selection; skips and selected conditions remain explicit.'
    witness = next(x for x in os_records if x['name'] == name)
    assert witness['identity_matches'] and witness['state'] == 'Z'
    assert witness['observed_recorder_exit'] == result['verifier_exit']
    bundle = runtime / result['bundle']
    identity, manifest = read(bundle / 'identity.json'), read(bundle / 'manifest.json')
    assert identity['head'] == command['source_before']['head']
    assert identity['manifest_sha256'] == command['before_digest'] == result['after_digest'] == sha(canonical(manifest))
    assert result['source_input_count'] == command['source_input_count'] == len(manifest)
    assert manifest == git_inputs(identity['head'], manifest)
    assert identity['runtime_sha256'] == sha(canonical(read(bundle / 'runtime.json')))
    assert identity['public_environment_sha256'] == sha(canonical(read(bundle / 'public-environment.json')))
    assert identity['runner_sha256'] == launch['runner_sha256'] == sha((bundle / 'runner.py').read_bytes())
    assert launch['launcher_sha256'] == sha((runtime / 'launch-durable.py').read_bytes())
    for path in sorted(run.iterdir()):
        assert path.is_file()
        include(path)
    include(launch_file)
    include(runtime / ('launch-' + name + '.log'))
    bundles.add(bundle.name)
    invocations.append({'name': name, 'head': identity['head'], 'bundle': bundle.name,
                        'command': name + '/command.json', 'process_exit': result['process_exit'],
                        'verifier_exit': result['verifier_exit'], 'counts': counts, 'scope': scope})

for name in sorted(bundles):
    for path in sorted((runtime / name).iterdir()):
        assert path.is_file()
        include(path)
for name in ('run-focused.py', 'launch-durable.py', 'recorder-tools.json', 'mysql-server-launch.json',
             'mysql-socket-mode.json', 'mysql-schema-create.json', 'mysql-server-version.json',
             'mysql-server-ready.json', 'mysql-server-stop.json', 'old-source-os-exit-observations.json',
             'transport-recovery-observation.json', 'engine-pre-dml-narrow-source-carry.json', 'engine-pre-dml-source-carry-clarification.json',
             'sqlite-skip-identity-reconciliation.json', 'sqlite-current-skip-identity-reconciliation.json', 'evidence-preparation-errors.json',
             'closed-recorder-os-exit-observations-2252.json', 'recorder-os-exit-observations-final.json',
             'pint-final.json', 'pint-current-raw-proof-final.json', 'database-census-list-only.json',
             'database-census-own-autoload-list-only.json',
             'database-census-normal-proxy-repaired.json', 'database-census-current-policy-self-tests.json', 'own-binary-proxy-repair.json',
             'census-own-autoload-output-cleanup.json', 'census-normal-proxy-output-cleanup.json',
             'tax-write-admission-independent-source-review-c2652593-20261014.md',
             'tax-write-admission-independent-repaired-source-review-868b1a34-20261014.md',
             'tax-write-admission-independent-public-id-source-review-38dea396-20261014.md',
             'tax-write-admission-independent-design-review-e1968ced-20261014.md',
             'tax-write-admission-independent-test-evidence-review-9b2f2e2e-20261014.md',
             'tax-write-admission-independent-test-evidence-review-9b2f2e2e-20261014.json',
             'tax-write-admission-independent-native-current-read-assessment-9b2f2e2e-20261014.md',
             'tax-write-admission-independent-current-read-repair-review-d4b33103-20261014.md',
             'tax-write-admission-independent-current-evidence-checkpoint-d4b33103-20261015.md',
             'tax-write-admission-independent-current-evidence-checkpoint-d4b33103-20261015.json'):
    include(runtime / name)
include(Path('/workspace/runtime/prepare-tax-write-mysql-20261014.py'), 'evidence-tools/prepare-private-mysql.py')
include(Path('/workspace/runtime/tax-write-own-autoload-census-20261014.py'), 'evidence-tools/own-autoload-census.py')
include(Path('/workspace/runtime/finalize-tax-write-runtime-receipts-20261014.py'), 'evidence-tools/finalize-runtime-receipts.py')
include(Path(__file__), 'evidence-tools/package-recorded-evidence.py')
assert read(runtime / 'mysql-server-stop.json')['process_exit'] == 0
pint = read(runtime / 'pint-current-raw-proof-final.json')
assert pint['process_exit'] == 0 and pint['before'] == pint['after']
census = read(runtime / 'database-census-own-autoload-list-only.json')
assert census['process_exit'] == 0 and all(census[k] for k in ('policy_script_unchanged', 'loaders_unchanged', 'head_unchanged', 'status_clean'))
for name, expected in census['outputs'].items():
    path = runtime / 'census-own-autoload-outputs' / name
    assert sha(path.read_bytes()) == expected
    include(path, 'census-list-only/own-autoload-adapter/' + name)
normal = read(runtime / 'database-census-normal-proxy-repaired.json')
assert normal['process_exit'] == 0
cleanup = read(runtime / 'census-normal-proxy-output-cleanup.json')
assert {x['name']: x['sha256'] for x in cleanup['exact_hash_archived_and_removed']} == normal['outputs']
assert all(not (root / name).exists() for name in normal['outputs'])
for name, expected in normal['outputs'].items():
    path = runtime / 'census-normal-proxy-outputs' / name
    assert sha(path.read_bytes()) == expected
    include(path, 'census-list-only/repaired-normal-proxy/' + name)
head = git('rev-parse', 'HEAD').decode().strip()
current = read(runtime / 'sqlite-tax-write-affected-current-raw-proof/result.json')
assert current['junit'] == {'tests': 176, 'assertions': 1273, 'failures': 0, 'errors': 0, 'skipped': 23}
native = read(runtime / 'mysql-tax-write-commit-and-history-current-raw-proof/result.json')
assert native['junit'] == {'tests': 11, 'assertions': 130, 'failures': 0, 'errors': 0, 'skipped': 0}
assert native['source_after'] == current['source_after']
prior_native = runtime / 'mysql-tax-write-commit-and-history-final'
current_native = runtime / 'mysql-tax-write-commit-and-history-current-raw-proof'
prior_command, current_command = read(prior_native / 'command.json'), read(current_native / 'command.json')
assert prior_command['selected_files'] == current_command['selected_files'] and prior_command['filter'] == current_command['filter']
def case_identities(path):
    return sorted((x.get('classname'), x.get('name')) for x in ET.parse(path).getroot().iter('testcase'))
assert case_identities(prior_native / 'junit.xml') == case_identities(current_native / 'junit.xml')
pair = read(runtime / 'mysql-tax-write-current-raw-proof-fixed/result.json')
assert pair['junit'] == {'tests': 2, 'assertions': 31, 'failures': 0, 'errors': 0, 'skipped': 0}
assert pair['source_after'] == current['source_after']
skips = read(runtime / 'sqlite-current-skip-identity-reconciliation.json')
assert skips['exact_policy_match'] and skips['reported_cases'] == 176 and skips['executed_cases'] == 153 and skips['skip_count'] == 23
assert skips['junit_sha256'] == sha((runtime / 'sqlite-tax-write-affected-current-raw-proof/junit.xml').read_bytes())
manifest = read(runtime / current['bundle'] / 'manifest.json')
assert git_inputs(head, manifest) == manifest
assert {p: sha((root / p).read_bytes()) for p in manifest} == manifest
loaders = read(runtime / current['bundle'] / 'runtime.json')['autoload']
assert {p: sha((root / p).read_bytes()) for p in loaders} == loaders
for digest, data in sorted(source_blobs.items()):
    members['source-blobs/' + digest] = data
index = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'candidate_head': head, 'invocations': invocations,
         'current_source_check_names': ['sqlite-tax-write-affected-current-raw-proof', 'mysql-tax-write-current-raw-proof-fixed', 'mysql-tax-write-commit-and-history-current-raw-proof'],
         'refreshed_native_case_identities_equal_prior_selection': True,
         'earlier_engine_carry_scope': 'Damaged target pre-DML refusal only; no full fixture or whole-app equality. See original carry and its append-only clarification.',
         'actual_phpunit_invocations': len(invocations), 'source_inventories': sorted(bundles),
         'source_inventory_count': len(bundles), 'source_blob_count': len(source_blobs),
         'source_blob_layout': 'Deduplicated exact Git blob bytes at source-blobs/<sha256>; each inventory maps repository path to sha256.',
         'current_input_count': len(manifest), 'route_input_count': sum(p.startswith('routes/') for p in manifest),
         'loader_hash_count': len(loaders), 'member_sha256': {n: sha(b) for n, b in sorted(members.items())},
         'archive_member_count': len(members),
         'limits': 'Overlapping focused selections, not full acceptance. Original application oracles and fixture/assertion failures preserved. Formatting/list-only census are not executed PHPUnit invocations. No Foundation/GitLab/host/provider/live/activation claim.'}
archive = packet / 'recorded-evidence.tar.gz'
assert not archive.exists() and not (packet / 'recorded-evidence-index.json').exists()
with archive.open('xb') as stream:
    with tarfile.open(fileobj=stream, mode='w:gz') as tar:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(members)
    for item in tar.getmembers():
        assert item.isfile() and item.name in members
        assert sha(tar.extractfile(item).read()) == index['member_sha256'][item.name]
index['archive_sha256'], index['archive_bytes'] = sha(archive.read_bytes()), archive.stat().st_size
with (packet / 'recorded-evidence-index.json').open('x') as stream:
    json.dump(index, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({k: index[k] for k in ('candidate_head', 'actual_phpunit_invocations', 'source_inventory_count',
                                       'source_blob_count', 'archive_member_count', 'archive_sha256', 'archive_bytes')}, indent=2))
