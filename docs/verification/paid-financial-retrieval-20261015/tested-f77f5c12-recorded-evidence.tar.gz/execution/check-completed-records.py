import hashlib,json,sys,xml.etree.ElementTree as ET
from pathlib import Path
r=Path('/workspace/runtime/paid-financial-retrieval-evidence-20261015')
def sha(b):return hashlib.sha256(b).hexdigest()
rows=[]
for p in sorted(r.glob('*/result.json')):
 d=json.loads(p.read_text());name=p.parent.name
 assert d['source_unchanged'] and d['source_head_unchanged'] and d['source_status_unchanged'] and d['runner_unchanged'] and d['autoload_unchanged']
 cmd=json.loads((p.parent/'command.json').read_text());bundle=r/d['bundle'];identity=json.loads((bundle/'identity.json').read_text())
 assert cmd['source_before']==d['source_after'] and cmd['bundle']==d['bundle'] and identity['head']==d['source_after']['head']
 assert sha((bundle/'runner.py').read_bytes())==identity['runner_sha256']==d['runner_after_sha256']
 assert sha((p.parent/'log.txt').read_bytes())==d['log_sha256']
 launch=json.loads((r/('launch-'+name+'.json')).read_text());witness=json.loads((p.parent/'supervisor-os-exit.json').read_text())
 assert all(launch[k]==witness[k] for k in ['pid','uid','process_start_ticks']) and witness['identity_matched'] and witness['state']=='Z'
 if d['junit'] is not None:
  e=ET.parse(p.parent/'junit.xml').getroot();cases=list(e.iter('testcase'));actual={'tests':len(cases),'assertions':sum(int(c.get('assertions','0')) for c in cases),'failures':sum(c.find('failure') is not None for c in cases),'errors':sum(c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases)}
  assert actual==d['junit']
  assert d['verifier_exit']==(0 if d['process_exit']==0 else 1)
 else:
  assert d['process_exit']==-15 and d['verifier_exit']==1 and d['junit_error'] is not None and name=='retrieval-native-original-controls'
 assert witness['observed_os_exit']==d['verifier_exit']
 rows.append({'name':name,'head':d['source_after']['head'],'junit':d['junit'],'php_exit':d['process_exit'],'recorder_exit':d['verifier_exit'],'observed_os_exit':witness['observed_os_exit'],'source_inputs':d['source_input_count']})
assert len(rows)==10, 'All six completed SQLite originals, interrupted native and three completed native selections required.'
prep=r/'retrieval-whole-repaired';assert not (prep/'result.json').exists() and not (prep/'junit.xml').exists();assert json.loads((prep/'supervisor-os-exit.json').read_text())['observed_os_exit']==1
assert json.loads((r/'mysql-server-stopped-state.json').read_text())['process_exit']==0
out={'mechanical_reconciliation_only':True,'review_approval':False,'completed_original_results':rows,'pre_php_setup_failure':'Originalmissing-PATH launch, no app counts; observedOS1.','scope':'Exact recorded invocation/JUnit/source/loader/runner/OS reconciliation only. Failed and interrupted originals remain failed; no final domain/evidence approval or broad host/matrix claim.'}
with (r/'completed-records-reconciliation.json').open('x') as f:json.dump(out,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'completed_original_result_count':len(rows),'pre_php_failure_preserved':True,'mechanical_exit':0}))
