import datetime,json,subprocess,time
from pathlib import Path
r=Path('/workspace/runtime/paid-financial-retrieval-evidence-20261015')
for name in ['retrieval-native-positive','retrieval-native-reopened-frame','retrieval-native-source-caps']:
 result=r/name/'result.json';witness=r/name/'supervisor-os-exit.json'
 while not result.exists() or not witness.exists():time.sleep(1)
 d=json.loads(result.read_text());s=json.loads(witness.read_text())
 assert d['process_exit']==d['verifier_exit']==s['observed_os_exit']==0
 assert d['junit']['tests']==2 and d['junit']['failures']==d['junit']['errors']==d['junit']['skipped']==0
 assert d['source_after']=={'head':'f77f5c12e590b2d9295ebff582b142b4091ff8c2','status':''}
container='va-studio-private-mysql-paid-financial-retrieval-20261015'
launch=json.loads((r/'mysql-server-launch.json').read_text())
actual=subprocess.check_output(['docker','inspect','--format','{{.Id}}',container],text=True).strip()
assert actual==launch['stdout'].strip()
argv=['docker','stop',container]
p=subprocess.run(argv,text=True,capture_output=True)
record={'argv':argv,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'process_exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'owned_container_id':actual,'scope':'Stop only the original owned local fixture after all three completed native checks and their observed exits. Retain datadir volume; unrelated containers untouched.'}
with (r/'mysql-server-stop.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
p.check_returncode()
argv=['docker','inspect','--format','{{json .State}}',container]
p=subprocess.run(argv,text=True,capture_output=True)
record={'argv':argv,'process_exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
with (r/'mysql-server-stopped-state.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
p.check_returncode();state=json.loads(p.stdout);assert not state['Running'] and state['ExitCode']==0
print(json.dumps({'owned_native_checks':3,'server_stopped':True,'container_exit':state['ExitCode']}),flush=True)
