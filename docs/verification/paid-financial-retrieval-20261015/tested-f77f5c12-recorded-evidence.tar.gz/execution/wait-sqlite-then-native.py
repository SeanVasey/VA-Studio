import json,subprocess,time
from pathlib import Path
r=Path('/workspace/runtime/paid-financial-retrieval-evidence-20261015')
result=r/'retrieval-whole-clock-fixture'/'result.json'
while not result.exists():time.sleep(1)
a=json.loads(result.read_text())
assert a['source_after']=={'head':'f77f5c12e590b2d9295ebff582b142b4091ff8c2','status':''}
assert a['process_exit']==a['verifier_exit']==0 and a['junit']['failures']==a['junit']['errors']==0 and a['junit']['skipped']==2
subprocess.run(['python3',str(r/'close-supervisor.py'),'retrieval-whole-clock-fixture'],check=True)
filter='original_positive_closure|changed_original_rows|sdk_exception_drains|callback_reopened_frame|failed_second_mint|original_rollback|native_older_source_deadline|attempt_before_original_commit|original_after_commit_failure|direct_pdo_commit'
subprocess.run(['python3',str(r/'launch-durable.py'),'--name','retrieval-native-original-controls','--driver','mysql','--timeout','1800','--continue-on-defect','--filter',filter,'tests/Feature/ProductionFinancialRetrieval/FinancialReadPlanTest.php'],check=True)
