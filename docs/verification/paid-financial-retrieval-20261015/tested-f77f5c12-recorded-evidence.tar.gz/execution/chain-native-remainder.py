import json,subprocess,time
from pathlib import Path
r=Path('/workspace/runtime/paid-financial-retrieval-evidence-20261015')
head='f77f5c12e590b2d9295ebff582b142b4091ff8c2'
def close_pass(name):
 result=r/name/'result.json'
 while not result.exists():time.sleep(1)
 a=json.loads(result.read_text())
 assert a['source_after']=={'head':head,'status':''}
 assert a['process_exit']==a['verifier_exit']==0 and a['junit']['tests']==2 and a['junit']['failures']==a['junit']['errors']==a['junit']['skipped']==0
 subprocess.run(['python3',str(r/'close-supervisor.py'),name],check=True)
 print(json.dumps({'completed':name,'junit':a['junit']}),flush=True)
close_pass('retrieval-native-positive')
for name,filter,timeout in [('retrieval-native-reopened-frame','callback_reopened_frame',1200),('retrieval-native-source-caps','native_older_source_deadline',2400)]:
 subprocess.run(['python3',str(r/'launch-durable.py'),'--name',name,'--driver','mysql','--timeout',str(timeout),'--continue-on-defect','--filter',filter,'tests/Feature/ProductionFinancialRetrieval/FinancialReadPlanTest.php'],check=True)
 close_pass(name)
