import datetime,hashlib,json,subprocess,sys
from pathlib import Path
root=Path('/workspace/VA-Studio-tax-v2-committed-read')
out=Path('/workspace/runtime/paid-financial-retrieval-cheap-20261015');out.mkdir(exist_ok=False)
commands=[['python3',f] for f in ['scripts/ci/test-ci-scope.py','scripts/ci/test-workflow-cadence.py','scripts/ci/test-focused-tests.py','scripts/ci/test-database-receipts.py','scripts/ci/test-gitlab-database-receipts.py','scripts/ci/test-gitlab-writer-feedback.py','scripts/ci/test-php-test-runtime.py','scripts/ci/test-phpunit-shards.py','scripts/dev/test-bootstrap-macos.py','scripts/test-publish-github.py']]
commands += [['composer','validate','--strict'],['composer','audit','--format=json'],['composer','check-platform-reqs'],['vendor/bin/pint','--test','app/Domain/Commerce/ProductionFinancialRetrieval','config/production-financial-retrieval.php','tests/Feature/ProductionFinancialRetrieval/FinancialReadPlanTest.php']]
state=lambda:{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True)}
before=state();assert before['status']==''
results=[]
for index,argv in enumerate(commands):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 result=subprocess.run(argv,cwd=root,text=True,capture_output=True)
 record={'argv':argv,'cwd':str(root),'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'source_before':before,'source_after':state()}
 with (out/(str(index).zfill(2)+'-'+Path(argv[1]).stem+'.json')).open('x') as s:json.dump(record,s,indent=2,sort_keys=True);s.write('\n')
 results.append({'argv':argv,'exit':result.returncode,'source_stable':record['source_after']==before})
 print(json.dumps(results[-1]),flush=True)
 if result.returncode or record['source_after']!=before:sys.exit(1)
(out/'summary.json').write_text(json.dumps({'source':before,'results':results,'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2,sort_keys=True)+'\n')
