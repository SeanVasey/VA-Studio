#!/usr/bin/env python3
import argparse,json,subprocess,datetime
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('argv',nargs=argparse.REMAINDER);a=p.parse_args();argv=a.argv[1:] if a.argv and a.argv[0]=='--' else a.argv;assert argv
root=Path('/workspace/VA-Studio-tax-v2-committed-read');out=Path('/workspace/runtime/paid-financial-retrieval-publication-20261015');out.mkdir(exist_ok=True);path=out/(a.name+'.json');assert not path.exists()
r=subprocess.run(argv,cwd=root,capture_output=True,text=True);record=dict(argv=argv,cwd=str(root),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=r.returncode,stdout=r.stdout,stderr=r.stderr);path.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'name':a.name,'exit':r.returncode,'head':record['head'],'record':str(path)}));raise SystemExit(r.returncode)
