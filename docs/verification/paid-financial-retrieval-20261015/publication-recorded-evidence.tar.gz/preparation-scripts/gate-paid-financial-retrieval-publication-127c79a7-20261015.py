import json,subprocess,datetime
from pathlib import Path
root=Path('/workspace/VA-Studio-tax-v2-committed-read')
out=Path('/workspace/runtime/paid-financial-retrieval-publication-20261015')
head='127c79a7dade4b4570927cdc752a4b5fc34c722a'
def record(name):
    d=json.loads((out/(name+'.json')).read_text());assert d['exit']==0;return json.loads(d['stdout'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
run=record('ledger-fix-run-final');assert run['headSha']==head and run['databaseId']==38770563763 and run['status']=='completed' and run['conclusion']=='success'
assert len(run['jobs'])==5
expected={'scope':'success','frontend':'success','backend-quality':'success','documentation':'skipped','Development preflight result':'success'}
assert {j['name']:j['conclusion'] for j in run['jobs']}==expected
pr=record('ledger-fix-final-review-check-inventory')['data']['repository']['pullRequest']
assert pr['number']==126 and pr['headRefOid']==head and pr['baseRefOid']=='0d7a7da24db2ef6dca76cd1f14ce1294bc1c7bb5'
assert pr['isDraft'] is False and pr['mergeable']=='MERGEABLE' and pr['mergeStateStatus']=='CLEAN'
for k in ['reviews','reviewThreads']:
    assert pr[k]['pageInfo']['hasNextPage'] is False
assert all(r['state'] in ['COMMENTED','APPROVED','DISMISSED'] for r in pr['reviews']['nodes'])
assert all(t['isResolved'] and not t['comments']['pageInfo']['hasNextPage'] for t in pr['reviewThreads']['nodes']), 'Every thread must be explicitly reconciled before merge'
contexts=pr['statusCheckRollup']['contexts'];assert contexts['pageInfo']['hasNextPage'] is False
assert not any(n.get('status') not in [None,'COMPLETED'] for n in contexts['nodes'])
assert record('ledger-fix-rules-read')==[]
assert record('ledger-fix-graphql-protection')['data']['repository']['defaultBranchRef']['branchProtectionRule'] is None
required=json.loads((out/'ledger-fix-required-checks-read.json').read_text());assert required['exit']==1 and 'no required checks reported' in required['stderr'].lower()
carry=json.loads(Path('/workspace/runtime/paid-financial-retrieval-publication-carry-127c79a7-20261015.json').read_text())
assert carry['reviewed_sha']==head and carry['open_source_test_packet_p0']==carry['open_source_test_packet_p1']==0 and carry['p1_documentation_finding']['local_disposition']=='addressed'
receipt={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_head':head,'preflight_run':run['databaseId'],'preflight_jobs':expected,'review_count':len(pr['reviews']['nodes']),'thread_count':len(pr['reviewThreads']['nodes']),'all_threads_resolved':True,'check_context_count':len(contexts['nodes']),'pagination_complete':True,'mergeable':pr['mergeable'],'merge_state':pr['mergeStateStatus'],'rules':[],'branch_protection':None,'supported_required_check_diagnostic':required['stderr'].strip(),'independent_publication_carry':carry['decision'],'scope':'Focused development gate only; readiness cancellation artifact retained; no settings change or bypass.'}
p=out/'pre-merge-gate-127c79a7.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
