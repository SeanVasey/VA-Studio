import json,subprocess,datetime
from pathlib import Path
root=Path('/workspace/VA-Studio-tax-v2-committed-read')
out=Path('/workspace/runtime/paid-financial-retrieval-publication-20261015')
head='5490d000c0069cfc2451d619f5f2fe352736c153'
def record(name):
    d=json.loads((out/(name+'.json')).read_text());assert d['exit']==0;return json.loads(d['stdout'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
run=record('replacement-run-final');assert run['headSha']==head and run['databaseId']==38769578051 and run['status']=='completed' and run['conclusion']=='success'
assert len(run['jobs'])==5
expected={'scope':'success','frontend':'success','backend-quality':'success','documentation':'skipped','Development preflight result':'success'}
assert {j['name']:j['conclusion'] for j in run['jobs']}==expected
pr=record('final-review-check-inventory')['data']['repository']['pullRequest']
assert pr['number']==126 and pr['headRefOid']==head and pr['baseRefOid']=='0d7a7da24db2ef6dca76cd1f14ce1294bc1c7bb5'
assert pr['isDraft'] is False and pr['mergeable']=='MERGEABLE' and pr['mergeStateStatus']=='CLEAN'
for k in ['reviews','reviewThreads']:
    assert pr[k]['pageInfo']['hasNextPage'] is False
    assert not pr[k]['nodes'], 'Nonempty reviews/threads require explicit reconciliation before merge'
contexts=pr['statusCheckRollup']['contexts'];assert contexts['pageInfo']['hasNextPage'] is False
assert not any(n.get('status') not in [None,'COMPLETED'] for n in contexts['nodes'])
assert record('rules-read')==[]
assert record('graphql-protection')['data']['repository']['defaultBranchRef']['branchProtectionRule'] is None
required=json.loads((out/'required-checks-read.json').read_text());assert required['exit']==1 and 'no required checks reported' in required['stderr'].lower()
carry=json.loads(Path('/workspace/runtime/paid-financial-retrieval-publication-carry-5490d000-20261015.json').read_text())
assert carry['reviewed_sha']==head and carry['open_p0']==carry['open_p1']==0
receipt={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_head':head,'preflight_run':run['databaseId'],'preflight_jobs':expected,'review_count':0,'thread_count':0,'check_context_count':len(contexts['nodes']),'pagination_complete':True,'mergeable':pr['mergeable'],'merge_state':pr['mergeStateStatus'],'rules':[],'branch_protection':None,'supported_required_check_diagnostic':required['stderr'].strip(),'independent_publication_carry':carry['decision'],'scope':'Focused development gate only; readiness cancellation artifact retained; no settings change or bypass.'}
p=out/'pre-merge-gate.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
