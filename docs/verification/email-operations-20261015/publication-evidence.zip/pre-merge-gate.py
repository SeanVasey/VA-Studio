import json,subprocess,datetime,hashlib
from pathlib import Path
root=Path('/workspace/VA-Studio-tax-v2-committed-read')
out=Path('/workspace/runtime/email-operations-publication-20261015')
head='9c01dffbd08dc50ac24d2098f15dfa59db73cc4e'
def record(name):
 d=json.loads((out/(name+'.json')).read_text());assert d['exit']==0;return json.loads(d['stdout'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
run=record('preflight-final');identity=json.loads((out/'latest-run-identity.json').read_text())
assert run['headSha']==head and run['databaseId']==identity['databaseId'] and run['status']=='completed' and run['conclusion']=='success'
expected={'scope':'success','frontend':'success','backend-quality':'success','documentation':'skipped','Development preflight result':'success'}
assert {j['name']:j['conclusion'] for j in run['jobs']}==expected
pr=record('final-review-check-inventory')['data']['repository']['pullRequest']
assert pr['number']==128 and pr['headRefOid']==head and pr['baseRefOid']=='81eb44b0f97e17bb39bccd7a1ba871a344773409'
assert not pr['isDraft'] and pr['mergeable']=='MERGEABLE' and pr['mergeStateStatus']=='CLEAN'
for k in ['reviews','reviewThreads']:assert not pr[k]['pageInfo']['hasNextPage']
assert all(r['state'] in ['COMMENTED','APPROVED','DISMISSED'] for r in pr['reviews']['nodes'])
assert all(t['isResolved'] and not t['comments']['pageInfo']['hasNextPage'] for t in pr['reviewThreads']['nodes'])
contexts=pr['statusCheckRollup']['contexts'];assert not contexts['pageInfo']['hasNextPage']
cancelled=record('ready-cancellation-final')
assert cancelled['headSha']==head and cancelled['databaseId']==38803887938 and cancelled['status']=='completed' and cancelled['conclusion']=='cancelled'
old_jobs={j['name']:j['conclusion'].upper() for j in cancelled['jobs']}
assert old_jobs=={'scope':'SUCCESS','frontend':'CANCELLED','backend-quality':'CANCELLED','documentation':'SKIPPED','Development preflight result':'FAILURE'}
latest_prefix='https://github.com/SeanVasey/VA-Studio/actions/runs/'+str(run['databaseId'])+'/job/'
old_prefix='https://github.com/SeanVasey/VA-Studio/actions/runs/38803887938/job/'
latest_contexts=[];cancelled_artifact_contexts=[]
for n in contexts['nodes']:
 if 'name' not in n:
  assert n['state']=='SUCCESS';continue
 assert n['status']=='COMPLETED'
 if n['detailsUrl'].startswith(old_prefix):
  assert n['name'] in old_jobs and n['conclusion']==old_jobs[n['name']]
  cancelled_artifact_contexts.append(n)
 else:
  assert n['conclusion'] in ['SUCCESS','SKIPPED','NEUTRAL']
  if n['detailsUrl'].startswith(latest_prefix):latest_contexts.append(n)
assert {n['name']:n['conclusion'].lower() for n in latest_contexts}==expected
assert len(latest_contexts)==5 and len(cancelled_artifact_contexts)==5
assert record('final-rules-read')==[]
assert record('final-protection-read')['data']['repository']['defaultBranchRef']['branchProtectionRule'] is None
required=json.loads((out/'final-required-checks-read.json').read_text());assert required['exit']==1 and 'no required checks reported' in required['stderr'].lower()
p=Path('/workspace/runtime/email-operations-publication-carry-9c01dffb-20261015.json');carry=json.loads(p.read_text())
assert carry['reviewed_sha']==head and carry['open_p0']==carry['open_p1']==0 and carry['required_corrections']==[]
assert carry['decision'].startswith('APPROVE')
receipt={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr':128,'expected_head':head,'preflight_run':run['databaseId'],'preflight_jobs':expected,'review_count':len(pr['reviews']['nodes']),'thread_count':len(pr['reviewThreads']['nodes']),'all_threads_resolved':True,'check_context_count':len(contexts['nodes']),'current_green_preflight_contexts':len(latest_contexts),'identified_readiness_cancellation_artifact_contexts':len(cancelled_artifact_contexts),'pagination_complete':True,'mergeable':pr['mergeable'],'merge_state':pr['mergeStateStatus'],'rules':[],'branch_protection':None,'supported_required_check_diagnostic':required['stderr'].strip(),'independent_publication_carry':carry['decision'],'independent_carry_original_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'Focused development gate only; no settings change/bypass or full host/provider activation acceptance.'}
p=out/'pre-merge-gate.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
