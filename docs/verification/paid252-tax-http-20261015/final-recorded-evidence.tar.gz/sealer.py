#!/usr/bin/env python3
import argparse,hashlib,json,subprocess,tarfile,io,gzip
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--label',required=True);a=p.parse_args()
root=Path('/workspace/VA-Studio-tax-v2-committed-read'); evidence=Path('/workspace/runtime/paid252-tax-http-evidence-20261015'); packet=root/'docs/verification/paid252-tax-http-20261015'
def sha(b): return hashlib.sha256(b).hexdigest()
files={}
for f in sorted(evidence.rglob('*')):
 if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc': files['execution/'+str(f.relative_to(evidence))]=f.read_bytes()
for f in sorted(Path('/workspace/runtime/paid252-tax-http-cheap-760c9388-20261015').glob('*.json')): files['cheap/'+f.name]=f.read_bytes()
files['sealer.py']=Path(__file__).read_bytes()
heads={}; loaders={}
for bundle in sorted(evidence.glob('bundle-*')):
 identity=json.loads((bundle/'identity.json').read_text()); manifest=json.loads((bundle/'manifest.json').read_text()); runtime=json.loads((bundle/'runtime.json').read_text()); head=identity['head'];mapping={}
 proc=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 try:
  for name,digest in sorted(manifest.items()):
   proc.stdin.write((head+':'+name+'\n').encode());proc.stdin.flush();h=proc.stdout.readline().split();assert len(h)==3 and h[1]==b'blob';n=int(h[2]);b=proc.stdout.read(n);assert len(b)==n and proc.stdout.read(1)==b'\n' and sha(b)==digest;files['source-blobs/'+digest]=b;mapping[name]=digest
 finally:
  proc.stdin.close();assert proc.wait()==0
 heads[head]=mapping
 for name,digest in runtime['autoload'].items():
  b=(root/name).read_bytes();assert sha(b)==digest;files['loader-blobs/'+digest]=b;loaders[name]=digest
files['git-source-bindings.json']=(json.dumps(heads,indent=2,sort_keys=True)+'\n').encode()
files['current-loader-bindings.json']=(json.dumps(loaders,indent=2,sort_keys=True)+'\n').encode()
index={name:sha(data) for name,data in files.items()}
archive=packet/(a.label+'-recorded-evidence.tar.gz');assert not archive.exists()
with archive.open('xb') as stream:
 with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for name,data in sorted(files.items()):
    member=tarfile.TarInfo(name);member.size=len(data);member.mtime=0;member.mode=0o600;tar.addfile(member,io.BytesIO(data))
r=dict(archive=archive.name,archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,members=len(files),digests=index,heads=list(heads),source_blob_count=sum(n.startswith('source-blobs/') for n in files),loader_count=len(loaders),scope='Original public execution/cheap records, exact immutable source blobs and matching observed loader bytes; ephemeral app key excluded by recorder. No app/full-native/host claim.')
(packet/(a.label+'-recorded-evidence-index.json')).write_text(json.dumps(r,indent=2,sort_keys=True)+'\n'); print(json.dumps({k:v for k,v in r.items() if k!='digests'},indent=2))
