## Why and what changes

Compose the retained Tax checkout and typed paid Tax grant/delivery domains into six private identifier-only consumer endpoints and guarded producer/root registration. Mount flags ship false and admit only exact true in local/testing; the default provider remains unbound. Original request budgets and response-owned read/transfer cleanup protect early admission, late refusal and never-started disposal.

## Scope

- Work package: CLAUDE-PLAN A3, advances default-false Tax HTTP composition.
- Changed surfaces: new Tax controller/codecs/read/response owner; root middleware, literal registration, routes and focused fixtures. Original domains/schema/frozen contracts/vendor stay unchanged.
- Remaining: A5 refund/dispute design, Tax UI/index, existing-request final provider-I/O and all merchant/host/release conditions.

## Verification

- Tested source: `bb3d29983d6d225cfb62d9607beaa54874f3aa03`, current app identical to `e3f06b084538dac11665ff9be77c74228bdab64d`; Final evidence approval `2a382a505c3145f709cede4110dbcd0b57196a3c`; receipt-only publication `f32b755c976f3c4f0ab3dc8c038fe6fc26d3273c`.

| Check / environment | Actual result | Evidence |
| --- | --- | --- |
| Whole new root SQLite file | 45/597, F0/E0/S0; PHP/recorder/observed OS0 | Packet |
| Repaired two-line exact PDF/master and elapsed timing | 2/40, F0/E0/S0; all0 | Packet |
| Original whole Tax/producer/V1 selection | 48/970, F0/E1/S0; 2/1/1, remains failed | Packet |
| Completed producer/V1 components within that run | 17/131 and19/648, zero failures/errors/skips; explicit prior-source carry | Packet |
| Genuine producer CSRF equality/mismatch/rotation | 1/17, F0/E0/S0; all0; disproves anticipated mapping concern | Packet |
| Pint all20 changed PHP files | pass, exit0 | Packet |
| All10 local safeguards | 263 pass, original source760; unchanged scripts/config carry | Packet |

No combined green48-case or whole green12-case Tax invocation is claimed. Eleven originals retain five passing/six nonzero outcomes, null counts for a fatal empty-JUnit run, exact source/argv/runtime/loader/exits and genuine corrections. No current MySQL/native, Foundation or GitLab dispatch; prior native carry covers only unchanged primitives. Local sessions/cache/SMTP/provider inputs are synthetic.

- Independent review: separate non-author original design/source/correction decisions at the packet; Final sealed evidence APPROVE WITH CONDITIONS at2a382a505, no open P0/P1/required correction; explicit doc-only publication carry applies to the final head. Exact-head preflight/protection inventory and expected-SHA merge remain.

## Risks and recovery

- Commerce/access: both root mounts and commerce policies remain off; private original source, current buyer and durable spent attempts stay domain-owned. Disposed/late-refused attachments do not erase an attempt. No live credentials/funds/active imports.
- Operations: config/route caches must be rebuilt for an authorized rehearsal. Runtime flags/environment independently refuse stale mounted routes. No schema change, host verification or deployment.
- Recovery: revert the new root/route boundary while retaining durable original evidence; preserve frozen contracts and prior release conditions.

## Handoff

- [Packet](docs/verification/paid252-tax-http-20261015/README.md), immutable original decisions and sealed archive/index.
- [Runbook](docs/ops/paid-tax-http-runtime.md). Actual merge receipt and both ledgers follow an expected-SHA merge after exact-head cheap preflight and full review/protection inventory.
