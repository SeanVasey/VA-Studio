<?php

// Explicit disposable native SQL diagnostic; no application authority or fixture claim.
$schema = 'vaseyaudio_paid252_tax_v2';
$socket = '/workspace/runtime/mysql-paid252-tax-v2-run/mysql.sock';
$table = 'va_paid_tax_snapshot_probe_20261015';
$connect = static fn () => new PDO('mysql:unix_socket='.$socket.';dbname='.$schema, 'root', '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$a = $connect();
$b = $connect();
$created = false;
$result = ['version' => $a->query('SELECT VERSION()')->fetchColumn(), 'schema' => $a->query('SELECT DATABASE()')->fetchColumn(),
    'isolation' => $a->query('SELECT @@session.transaction_isolation')->fetchColumn(), 'observations' => []];
if ($result['schema'] !== $schema || $a->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='$table'")->fetchColumn() !== 0) {
    throw new LogicException('Owned isolated diagnostic prerequisites refused.');
}
try {
    $a->exec("CREATE TABLE `$table` (id BIGINT UNSIGNED PRIMARY KEY, v INT NOT NULL) ENGINE=InnoDB");
    $created = true;
    $a->exec("CREATE TRIGGER `{$table}_bi` BEFORE INSERT ON `$table` FOR EACH ROW SET NEW.v=NEW.v");
    $a->exec("INSERT INTO `$table` VALUES (1,0)");
    $queries = [
        'none' => null,
        'limit-zero' => "SELECT 1 FROM `$table` LIMIT 0",
        'show-create' => "SHOW CREATE TABLE `$table`",
        'information-schema-tables' => 'SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE()',
        'information-schema-triggers' => 'SELECT TRIGGER_NAME,ACTION_STATEMENT FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE()',
        'show-triggers' => "SHOW TRIGGERS WHERE `Table`='$table'",
    ];
    foreach ($queries as $name => $sql) {
        $b->exec("UPDATE `$table` SET v=0 WHERE id=1");
        $a->beginTransaction();
        if ($sql !== null) {
            $a->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        }
        $b->exec("UPDATE `$table` SET v=1 WHERE id=1");
        $locked = $a->query("SELECT v FROM `$table` WHERE id=1 FOR UPDATE")->fetchColumn();
        $plain = $a->query("SELECT v FROM `$table` WHERE id=1")->fetchColumn();
        $current = $a->query("SELECT v FROM `$table` WHERE id=1 FOR UPDATE NOWAIT")->fetchColumn();
        $a->rollBack();
        $result['observations'][$name] = ['locking_read' => $locked, 'plain_read' => $plain, 'repeat_current_read' => $current];
    }
} finally {
    foreach ([$a,$b] as $pdo) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
    }
    if ($created) {
        $a->exec("DROP TABLE `$table`");
    }
}
$result['owned_probe_removed'] = $a->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='$table'")->fetchColumn() === 0;
echo json_encode($result, JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR).PHP_EOL;
