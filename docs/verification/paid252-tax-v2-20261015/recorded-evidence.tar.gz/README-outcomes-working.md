| mysql-origin-race-and-objects-first | `64cfd5101a3484687c97cdf94c57ef0738c07ef0` | 1/3; F0 E1 S0 | 2/1/1 |
| mysql-origin-race-gated-and-recovery | `fee317f1ab46a4350d41be630911d5b0edf3fd85` | 1/33; F1 E0 S0 | 1/1/1 |
| mysql-origin-race-objects-and-recovery-corrected | `160ff441f3bcc997d0f9bd636a7d784119e15c13` | 1/625; F1 E0 S0 | 1/1/1 |
| mysql-provider-case-corrected-fixture-old-source | `f3aa1f1fa6565b38e676a160e2aba9d1840f9856` | 1/3; F0 E1 S0 | 2/1/1 |
| mysql-provider-case-fixed | `8ae2903be6c259e1465830f0e1ca792308b00c58` | 1/12; F0 E0 S0 | 0/0/0 |
| mysql-provider-case-old-source | `16a1a8f15ded4256a90a87d819bae5902cfe1c17` | 1/2; F0 E1 S0 | 2/1/1 |
| pure-capabilities-fixed | `51257e9675af14d794e4e2ac16182dd98966ee3f` | 3/4; F0 E0 S0 | 0/0/0 |
| pure-deadline-deserialization-old-source | `ba6596285f1d0ecac7ef1d5cc92542fce6e16b65` | 1/1; F1 E0 S0 | 1/1/1 |
| pure-distinct-transport-protocol | `7f9f9ac6d53430f8e504ed6c33946bbfd45ed12e` | 1/4; F0 E0 S0 | 0/0/0 |
| sqlite-adversarial-boundaries-corrected-fixture | `c917abab04852252523dbcb370494e8f4df24074` | 15/2172; F0 E1 S0 | 2/1/1 |
| sqlite-adversarial-boundaries-first | `e38ece6ef267b697c2d67d8dbf41af053a4e3d0d` | 3/19; F0 E1 S0 | 2/1/1 |
| sqlite-before-bytes-cleanup-old-source | `250295bea54c7b6ba2f3dfa5776d0cba46ad09a2` | 1/8; F1 E0 S0 | 1/1/1 |
| sqlite-begin-birth-fixed | `8ae2903be6c259e1465830f0e1ca792308b00c58` | 4/54; F0 E0 S0 | 0/0/0 |
| sqlite-begin-throw-old-source | `ba89be684e81408e1fd8286fd0bc9880b97e86a9` | 1/6; F1 E0 S0 | 1/1/1 |
| sqlite-cold-schema-fixed | `5ed4f8d01b54eb9ee23d6856d23c5866a42020ca` | 1/6; F0 E0 S0 | 0/0/0 |
| sqlite-cold-schema-old-source | `2f181f55796e4e51fc754461b0095c23887a5c36` | 1/3; F1 E0 S0 | 1/1/1 |
| sqlite-commit-boundaries-first | `7ef0fd778e3c5a52463789918765a3f5ac6eb3f2` | 4/33; F1 E0 S0 | 1/1/1 |
| sqlite-consumer-family-and-recovery | `8a35c90f84052531f4f1189fcd806d6afdda4e43` | 8/74; F1 E0 S0 | 1/1/1 |
| sqlite-delayed-claim-clock-old-source | `f3aa1f1fa6565b38e676a160e2aba9d1840f9856` | 1/8; F1 E0 S0 | 1/1/1 |
| sqlite-family-and-recovery-corrected-refusal | `b77819229546b88bfa76c0b9049eabe41b852d7b` | 19/2230; F0 E0 S1 | 0/0/0 |
| sqlite-fresh-environment-fixed | `1e6e103101865eff0dfe6cfd7ac8a3fa1d9ace7e` | 3/5; F0 E0 S0 | 0/0/no portable witness |
| sqlite-fresh-environment-old-source | `c2c1d16a9660820153dc11f6e3a7c489aa6e8130` | 1/1; F1 E0 S0 | 1/1/no portable witness |
| sqlite-fresh-policy-compatibility | `1e6e103101865eff0dfe6cfd7ac8a3fa1d9ace7e` | 46/152; F0 E0 S0 | 0/0/no portable witness |
| sqlite-origin-amounts | `42774b742b9536413c753bc40297646db0886207` | 3/66; F0 E0 S0 | 0/0/0 |
| sqlite-origin-first | `42774b742b9536413c753bc40297646db0886207` | 1/22; F0 E0 S0 | 0/0/0 |
| sqlite-original-first | `b57d1f1642d4b437cf0727ad032cca63fb39670a` | 1/23; F0 E0 S0 | 0/0/0 |
| sqlite-owned-frame-and-clock-repair | `51257e9675af14d794e4e2ac16182dd98966ee3f` | 8/72; F0 E0 S0 | 0/0/0 |
| sqlite-pre-source-reopen-old-source | `ba6596285f1d0ecac7ef1d5cc92542fce6e16b65` | 1/4; F1 E0 S0 | 1/1/1 |
| sqlite-prestart-and-begin-fixed | `035e7cd885e29754af81a549061b6ae00d4e8823` | 7/86; F0 E0 S0 | 0/0/0 |
| sqlite-prestart-displacement-old-source | `5a3e1b794eec254a24649a164027114ac5d54767` | 1/6; F1 E0 S0 | 1/1/1 |
| sqlite-two-line-recovery-first | `b57d1f1642d4b437cf0727ad032cca63fb39670a` | 1/17; F0 E0 S0 | 0/0/0 |
