import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path('/tmp/VA-Studio-staff-mfa-leftovers-20261015')
publication = Path('/tmp/fixture-admission-publication-20261015')
runtime = Path('/tmp/fixture-admission-evidence-20261015')
packet = root / 'docs/verification/fixture-admission-20261015'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def git_blob(revision, path):
    return subprocess.check_output(['git', 'show', revision + ':' + path], cwd=root)

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == '07a256d2bc6acd576b4e4eae6c3462da6f110859'
path = 'scripts/ci/database-sqlite-skips.json'
base = json.loads(git_blob('f3b00476218e54f45ad1ee435e0fc5de115d717b', path))
previous = json.loads(git_blob('5ef21c28d82a56197469d1222bf119b93aac9c41', path))
current = json.loads(git_blob(head, path))
original = base['methods']
added = [method for method in previous['methods'] if method not in original]
assert len(added) == 5 and current['methods'] == original + added
assert sorted(previous['methods']) == sorted(current['methods'])
prefix_hash = sha(json.dumps(current['methods'][:150], separators=(',', ':')).encode())
assert prefix_hash == 'd93da4e7a13a8c6aff8f97f363eb6d93dde884bad53c9ae50eeb0ed32514c71c'
changed = subprocess.check_output(['git', 'diff', '--name-only', '5ef21c28', head], cwd=root, text=True).splitlines()
assert changed == [path]
archive = packet / 'prefix-correction-evidence.zip'
assert not archive.exists()
members = [publication / 'failed-preflight-completed.json', publication / 'routing-safeguards-local-original.json']
for name in ['focused-selection-prefix-corrected-original', 'shard-policy-prefix-corrected-original', 'php-runtime-activated-original']:
    record = json.loads((runtime / (name + '.json')).read_text())
    assert record['process_exit'] == 0 and record['source_unchanged']
    assert record['source_before']['head'] == head
    assert sha((runtime / (name + '.log')).read_bytes()) == record['log_sha256']
    members += [runtime / (name + '.json'), runtime / (name + '.log')]
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
    for source in members:
        zipped.writestr(source.name, source.read_bytes())
private = []
for name in ['backend-failure-log-original', 'backend-failure-log-corrected-original']:
    source = publication / (name + '.json')
    record = json.loads(source.read_text())
    private.append({'name': source.name, 'sha256': sha(source.read_bytes()), 'exit': record['exit'], 'reason_private': 'Log-fetch error contains a temporary signed download URL; raw stderr is not published.'})
local = json.loads((publication / 'routing-safeguards-local-original.json').read_text())
summary = {
    'corrected_source': head,
    'changed_source_inputs_since_approved_5ef': changed,
    'original_method_order_preserved_count': len(original),
    'same_five_added_methods': added,
    'original_first_150_sha256_unchanged': prefix_hash,
    'method_set_unchanged_since_failed_head': True,
    'original_focused_archive_sha256_unchanged': sha((packet / 'focused-evidence.zip').read_bytes()),
    'correction_archive_sha256': sha(archive.read_bytes()),
    'correction_archive_members': [{'name': p.name, 'sha256': sha(p.read_bytes())} for p in members],
    'failed_preflight': {'run': 38821013983, 'head': '5ef21c28d82a56197469d1222bf119b93aac9c41', 'conclusion': 'failure', 'backend_step': 'Verify CI routing and focused-selection safeguards'},
    'original_local_reproduction': [{'argv': command['argv'], 'exit': command['exit']} for command in local['commands']],
    'local_runtime_failure_reconciliation': 'Original local PHP runtime check had 4 failures of 5 because PHP was absent from PATH; activated PHP8.4 rerun passes 5. This local setup error is not identified as the CI failure.',
    'corrected_counts': {'focused_selection': 50, 'shard_policy': 52, 'php_runtime': 5},
    'corrected_checks_each_exit_zero': True,
    'private_log_fetch_receipts': private,
    'limits': 'Only census order corrected. Prior passing app/native scopes carried unchanged; native lifecycle4/8/E4 and older default1/2/E1 remain failed/open. No full manifest equality claim after one policy input changes. Exact new-head cheap preflight and independent carry remain pending.'
}
assert summary['original_focused_archive_sha256_unchanged'] == '7976add384769b1e6b5c8c701ffce9158e7928cc6a68790b59568283964293f6'
with (packet / 'prefix-correction-index.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: summary[key] for key in ['corrected_source', 'original_method_order_preserved_count', 'original_first_150_sha256_unchanged', 'correction_archive_sha256', 'corrected_counts']}, indent=2))
