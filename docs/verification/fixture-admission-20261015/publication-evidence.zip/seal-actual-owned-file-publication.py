import argparse,hashlib,json,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--head',required=True);p.add_argument('--carry-prefix',required=True);a=p.parse_args()
root=Path('/tmp/VA-Studio-staff-mfa-leftovers-20261015');runtime=Path('/tmp/fixture-admission-publication-20261015');packet=root/'docs/verification/fixture-admission-20261015'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(name):return json.loads((runtime/(name+'.json')).read_text())
actual=read('actual-merge-owned-file');gate=read('pre-merge-gate-owned-file')
assert actual['approved_head']==gate['expected_head']==a.head and len(a.head)==40
assert actual['merged_tree']==actual['approved_tree']
assert actual['parents']==['f3b00476218e54f45ad1ee435e0fc5de115d717b',a.head]
carry=Path(a.carry_prefix+'.json');review=json.loads(carry.read_text())
assert review['reviewed_sha']==a.head and review['open_p0']==review['open_p1']==0 and not review['required_corrections']
for suffix in ['md','json']:
 source=Path(a.carry_prefix+'.'+suffix);target=packet/('independent-owned-file-publication-carry-'+a.head[:8]+'.'+suffix);assert not target.exists();target.write_bytes(source.read_bytes())
private_names={'backend-failure-log-original.json','backend-failure-log-corrected-original.json'}
members=[p for p in sorted(runtime.glob('*.json')) if p.name not in private_names]+sorted(runtime.glob('*.py'))+sorted(runtime.glob('*.graphql'))
archive=packet/'publication-evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as zipped:
 for source in members:zipped.writestr(source.name,source.read_bytes())
receipt=dict(archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,members=[dict(name=p.name,sha256=sha(p.read_bytes())) for p in members],actual_merge=actual,pre_merge_gate=gate,private_log_fetch_receipts=[dict(name=n,sha256=sha((runtime/n).read_bytes()),reason='Contains a temporary signed log URL; raw stderr remains private.') for n in sorted(private_names)],scope='Actual bounded F2a merge; all historical failures and current closures retained. Native lifecycle/fullF2/provider/host/activation/release remain open; no Foundation/GitLab dispatch.')
with (packet/'publication-receipt.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
text=f"""# Actual F2a development merge

PR [#131](https://github.com/SeanVasey/VA-Studio/pull/131) merged at `{actual['merge_sha']}` on {actual['merged_at']}, from exact independently approved head `{a.head}`. Cheap preflight{gate['preflight_run']} passed scope/frontend/backend-quality/aggregate; documentation skipped. Separate final source/sealed-evidence and exact-head documentary carry approve with no P0/P1 or required correction.

Complete current inventory has {gate['review_count']} reviews/{gate['thread_count']} threads/{gate['context_count']} contexts with complete pagination. Every current context passes/skips; repository rules/protection remain unchanged. Expected-SHA merge0 and fetched tree `{actual['merged_tree']}` equal the approved head, with actual parents recorded.

The earlier two P1 threads were each replied to once/resolved after final4eb8 review. Current owned-fixture P1 r4289377653 and local-focused P2 r4289377661 were independently approved for closure, each replied to once/resolved. New bounded source owns private SQLite file allocation/config/Connection/PDO/canonical file+directory identity/release, remaining owned-memory Guards entrypoints and exact local MySQL declaration without manufactured CI. Query-only restored snapshots remain unregistered destructive targets.

Completed current scopes are separate: wholeSQLite31/722 and disjoint112/1288; native-outer86/1671 (26shared/195+5SQLiteRestore/527+46SQLitecanaries/932+9native/17), partialnativeGuardfourentrypoints4/13, actuallocalexactmarker1/2 and actualCI1/2, eachF0E0S0/exits0. Original oldrestore5/E5, ONEoldnativeadapter1/E1, firstnew31/E1, localmissing/wrong1/E1 and mistakenly expanded15-case selection interruptedPHP-15/emptyXML/NULLcounts remain failed originals; no partial pass. Focused53/Pint4/shard52/cadence14 pass0, while original53/F1 and52/F1 remain. Discovery2432/233of9202/677 is listing only. All56frozenpaths unchanged.

Original271member, eight-member census and112member priorP1 seals remain unchanged. Current12-invocation/156member seal SHA256 `b165eb65c82920b1bbb57bfa00ea244860b7102e4b1bcd17c7902cdda03395b0` retains source/runner/physical-loader bindings and privately hash-bound failed outputs. MySQL8.4.11 owned33524 normal SQLshutdown0/current-start shutdownlogged/socket+PIDgone/datadirretained; firstten-second reconciliation1 and later read-only confirmation retained separately.

Historical genuine backend-preflight38821013983 failure and readiness cancellation38821001027 remain nonpasses; pinned first150 census correction preserves original260 order/samefive/hash/assertions. Local PHP-PATH/CLI preparation failures and corrected commands are retained. Signed hosted-log download errors remain private; no unavailable hosted traceback claim.

Native lifecycle whole4/8/E4 and olddefault1/2/E1 remain failed/open. Only one older dataset timeout is established. FullF2/remaining25counterparts/rawworker/laterhook/whole-nativeGuard/concurrency/performance/provider/host/activation/release and prior frozenP2s remain. No Foundation/GitLab/live/deploy/DNS/cutover/frozen edit. Next: fixed native-only fixture-process calibration and unchanged wholefour lifecycle cases, preserving SQLite90seconds and every assertion/cleanup.

Publication archive:{len(members)}members/{archive.stat().st_size}bytes, SHA256 `{receipt['archive_sha256']}`. The current development agenda governs remaining dependency-ready implementation and production preparation.
"""
with (packet/'merge-receipt.md').open('x') as f:f.write(text)
ledger=f"\n\n2026-10-16 F2a merged PR #131 at `{actual['merge_sha']}`, exact approved `{a.head}`, cheap{gate['preflight_run']} SUCCESS; complete{gate['review_count']}reviews/{gate['thread_count']}threads/{gate['context_count']}contexts, unchangedprotections/expectedSHAmerge0/fetchedtreeequal. Separatefinalsealed/exactcarryapprove/noP0P1; earlier twoP1s and currentownedfixtureP1/localfocusedP2 eachreplyonce/resolved. WholeSQLite31/722 +disjoint112/1288,nativeouter86/1671(includesSQLitefixturebodies),partialnativeGuardentrypoints4/13,actuallocalexact/CI1/2 eachF0E0S0/exits0;12currentoriginals/156memberseal +older271/eight/112seals unchanged, allnonzeros/interruptedNULLcounts retained. OwnMySQL8.4.11 shutdown0/laterread-onlyreconciliation/datadirretained; firstboundedstopcheck1 retained. [Actual receipt](../../verification/fixture-admission-20261015/merge-receipt.md). Nativewholelifecycle4/E4+old1/E1/fullF2/25counterparts/rawworkers/host/activation/release/priorP2s remainopen. Nextfixednativechildbudgetcalibration/wholefour/SQLitecompat; no Foundation/GitLab/live/hostclaim/frozenedit.\n"
for name in ['CLAUDE-PLAN.md','codex-deferred-20261011.md']:
 p=root/'docs/handoff/2026-10-07'/name;p.write_text(p.read_text()+ledger)
print(json.dumps(dict(merge_sha=actual['merge_sha'],archive_members=len(members),archive_sha256=receipt['archive_sha256']),indent=2))
