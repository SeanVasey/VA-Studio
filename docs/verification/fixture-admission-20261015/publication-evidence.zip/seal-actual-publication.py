import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path('/tmp/VA-Studio-staff-mfa-leftovers-20261015')
runtime = Path('/tmp/fixture-admission-publication-20261015')
packet = root / 'docs/verification/fixture-admission-20261015'
approved = '27b998fe95e481c4b114b2047164b0ed2e5e9581'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def read(name):
    return json.loads((runtime / (name + '.json')).read_text())

actual = read('actual-merge-p1')
gate = read('pre-merge-gate-p1')
assert actual['approved_head'] == approved and gate['expected_head'] == approved
assert actual['merged_tree'] == actual['approved_tree']
assert actual['parents'] == ['f3b00476218e54f45ad1ee435e0fc5de115d717b', approved]
private_names = {'backend-failure-log-original.json', 'backend-failure-log-corrected-original.json'}
members = [p for p in sorted(runtime.glob('*.json')) if p.name not in private_names]
members += sorted(runtime.glob('*.py')) + sorted(runtime.glob('*.graphql'))
for suffix in ['md', 'json']:
    source = Path('/tmp/fixture-admission-p1-publication-carry-27b998fe-20261015.' + suffix)
    target = packet / ('independent-publication-carry-27b998fe.' + suffix)
    assert not target.exists()
    target.write_bytes(source.read_bytes())
archive = packet / 'publication-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
    for source in members:
        zipped.writestr(source.name, source.read_bytes())
receipt = {
    'archive_sha256': sha(archive.read_bytes()),
    'archive_bytes': archive.stat().st_size,
    'members': [{'name': p.name, 'sha256': sha(p.read_bytes())} for p in members],
    'actual_merge': actual,
    'pre_merge_gate': gate,
    'private_log_fetch_receipts': [{'name': name, 'sha256': sha((runtime / name).read_bytes()), 'reason': 'Contains a temporary signed log URL; raw stderr is retained privately only.'} for name in sorted(private_names)],
    'scope': 'Actual bounded F2a development merge. Original genuine failed preflight, readiness cancellation and CLI preparation failures retained. Native lifecycle remains failed/open; no Foundation/GitLab or host/activation claim.'
}
with (packet / 'publication-receipt.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
text = f'''# Actual F2a development merge

PR [#131](https://github.com/SeanVasey/VA-Studio/pull/131) merged at `{actual['merge_sha']}` on {actual['merged_at']}, from exact independently approved head `{approved}`. Cheap preflight{gate['preflight_run']} passed: scope, frontend, backend-quality and aggregate success; documentation skipped. Separate source/final evidence decisions and narrow census correction07a, P1 remediation305e/final4eb8 plus exact publication carry27b approve with no P0/P1 or required correction.

Genuine failed old-head preflight38821013983 remains failed; readiness-cancelled38821001027 remains a cancellation artifact. Census repair preserves all260 original methods/order, the samefive added methods and original pinned150-entry hash/assertions. Corrected local safeguards50/52/5 pass separately. The original local PHP-PATH preparation failure, malformed GraphQL file argument and deprecated GitHub CLI description update remain retained with successful corrected commands. Two unsuccessful signed-log downloads are privately hash-bound only; unavailable hosted traceback is not claimed.

Complete current inventory has {gate['review_count']} reviews/{gate['thread_count']} threads/{gate['context_count']} contexts with no further pages; all current contexts pass/skip. Repository rules=[]/protection=null unchanged; supported required-check command reports no required checks. Expected-SHA merge0 and fetched tree `{actual['merged_tree']}` equal the approved head; actual parents are recorded.

Final305e wholeSQLite103/1318 and native-outer74/1105 plus actualfocusedCI-marker1/2 remain separate completed scopes, eachF0/E0/S0/exits0. Native74 includes46SQLitecanaries/932,19shared admission/156 and9actualnative identity/refusal/17. Current six-original P1 seal retains oldnative46/E46 and missingmarker1/E1. Both P1 threads are resolved after one evidence-backed reply each; independent final4eb8 review approved their source/evidence closure. No hosted focused dispatch is claimed. Nativewhole4/8/E4 and olddefault1/2/E1 remain failed/open; only one older dataset timeout is established. Fourteen PHP originals and the original271member seal are unchanged. All25SQLite-only counterpart mapping, rawworker/laterhook boundaries/fullF2/native/concurrency/performance/host/session/provider/activation/release and prior P2s remain open. No Foundation/GitLab/live/deploy/DNS/cutover or frozen member/manifest change.

Publication archive: {len(members)} members/{archive.stat().st_size} bytes, SHA256 `{receipt['archive_sha256']}`. Next: bounded MySQL-only lifecycle fixture-process calibration and unchanged whole four-case native suite, preserving SQLite90seconds and all assertions/cleanup.
'''
with (packet / 'merge-receipt.md').open('x') as stream:
    stream.write(text)
ledger = f'''\n\n2026-10-15 F2a fixture admission merged: PR #131 at `{actual['merge_sha']}`, exact approved head `{approved}`, cheap{gate['preflight_run']} SUCCESS, complete current inventory{gate['review_count']}/{gate['thread_count']}/{gate['context_count']} with no further pages, unchanged protections, expectedSHAmerge0/fetchedtreeequal. Independent final/correction/exactcarry approve/noP0P1. Actual receipts retain genuine failed38821013983, readiness cancellation38821001027, local PHP/CLI errors and successful corrections; original271member seal unchanged. Final305eSQLite103/1318,nativeouter74/1105(includes46SQLitecanaries/932+19shared/156+9native/17),actualfocusedCI-marker1/2 remain separateF0E0S0 passing scopes; bothP1threads resolved after one evidence-backedreplyeach/final4eb8review; originalcontrols46/E46+1/E1 and112membersixoriginalseal retained; nativewhole4/8/E4 and olddefault1/2/E1 remain failed/open. [Actual receipt](../../verification/fixture-admission-20261015/merge-receipt.md). Only bounded pre-trait/captured cleanup scope closed; all25 counterpart mapping/rawworker/laterhook/fullF2/performance/host/activation/release/earlierP2s remain. Next fixednative fixture-process budget calibration/wholefourcases, SQLite90/assertions unchanged. No Foundation/GitLab/live/hostclaim or frozen edit.\n'''
for name in ['CLAUDE-PLAN.md', 'codex-deferred-20261011.md']:
    path = root / 'docs/handoff/2026-10-07' / name
    path.write_text(path.read_text() + ledger)
print(json.dumps({'merge_sha': actual['merge_sha'], 'archive_members': len(members), 'archive_sha256': receipt['archive_sha256']}, indent=2))
