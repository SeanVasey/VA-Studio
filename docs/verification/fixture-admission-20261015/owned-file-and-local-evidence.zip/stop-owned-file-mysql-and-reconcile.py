from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
out=Path('/tmp/fixture-admission-evidence-20261015/mysql-standalone')
datadir=Path('/tmp/va-studio-fixture-admission-mysql-data-standalone-20261015')
socket=Path('/tmp/va-studio-fixture-admission-mysql-socket-standalone-20261015/mysql.sock')
assert socket.exists() and datadir.is_dir()
pid=int((out/'mysqld.pid').read_text())
assert Path('/proc')/str(pid) != Path('/proc/self')
argv=(Path('/proc')/str(pid)/'cmdline').read_bytes().split(b'\0')
assert ('--datadir='+str(datadir)).encode() in argv
assert '--port=33524'.encode() in argv
r=subprocess.run(['python3','/tmp/fixture-admission-evidence-20261015/prepare-standalone-mysql-owned-file.py','--stage','stop'])
r.check_returncode()
for _ in range(100):
 if not socket.exists() and not (Path('/proc')/str(pid)).exists(): break
 time.sleep(.1)
log=(out/'server.log').read_bytes()
record=dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),shutdown_command_exit=r.returncode,socket_gone=not socket.exists(),pid_gone=not (Path('/proc')/str(pid)).exists(),normal_shutdown_logged=b'Shutdown complete' in log,server_log_private_sha256=hashlib.sha256(log).hexdigest(),datadir_retained=str(datadir),owned_pid=pid)
assert record['socket_gone'] and record['pid_gone'] and record['normal_shutdown_logged'] and datadir.is_dir()
with (out/'owned-file-stop-reconciliation.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record,indent=2))
