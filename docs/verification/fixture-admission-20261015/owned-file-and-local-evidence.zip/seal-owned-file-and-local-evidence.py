import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path('/tmp/VA-Studio-staff-mfa-leftovers-20261015')
runtime = Path('/tmp/fixture-admission-evidence-20261015')
packet = root / 'docs/verification/fixture-admission-20261015'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
def blob(head, name):
    return subprocess.check_output(['git', 'show', head + ':' + name], cwd=root)

names = ['owned-file-restore-old-original', 'owned-memory-guards-old-native-original',
    'owned-file-admission-and-restore-fixed-original', 'owned-file-admission-and-restore-recipe-corrected-original',
    'focused-local-marker-missing-original', 'focused-local-marker-wrong-original', 'focused-local-marker-exact-original',
    'owned-file-current-focused-ci-original', 'owned-file-sqlite-surrounding-whole-original',
    'owned-file-guards-four-entrypoints-native-original', 'owned-file-guards-four-entrypoints-exact-native-original',
    'owned-file-current-native-compatibility-whole-original']
expected_results = {
    'owned-file-restore-old-original': (2, 1, 5, 5),
    'owned-memory-guards-old-native-original': (2, 1, 1, 1),
    'owned-file-admission-and-restore-fixed-original': (2, 1, 31, 1),
    'owned-file-admission-and-restore-recipe-corrected-original': (0, 0, 31, 0),
    'focused-local-marker-missing-original': (2, 1, 1, 1),
    'focused-local-marker-wrong-original': (2, 1, 1, 1),
    'focused-local-marker-exact-original': (0, 0, 1, 0),
    'owned-file-current-focused-ci-original': (0, 0, 1, 0),
    'owned-file-sqlite-surrounding-whole-original': (0, 0, 112, 0),
    'owned-file-guards-four-entrypoints-exact-native-original': (0, 0, 4, 0),
    'owned-file-current-native-compatibility-whole-original': (0, 0, 86, 0),
}
members = {}
private = []
outcomes = []
bundles = set()
for name in names:
    directory = runtime / name
    command = json.loads((directory / 'command.json').read_text())
    result = json.loads((directory / 'result.json').read_text())
    assert all(result[k] for k in ['source_unchanged', 'source_head_unchanged', 'source_status_unchanged', 'runner_unchanged', 'autoload_unchanged'])
    if name == 'owned-file-guards-four-entrypoints-native-original':
        assert result['process_exit'] == -15 and result['verifier_exit'] == 1
        assert result['junit'] is None and result['junit_error'] is not None
    else:
        assert result['junit_error'] is None and result['junit']['skipped'] == 0
        assert (result['process_exit'], result['verifier_exit'], result['junit']['tests'], result['junit']['errors']) == expected_results[name]
        assert result['junit']['failures'] == 0
        import xml.etree.ElementTree as ET
        counts = result['junit']
        cases = list(ET.parse(directory / 'junit.xml').getroot().iter('testcase'))
        assert len(cases) == counts['tests']
        assert sum(int(case.get('assertions', '0')) for case in cases) == counts['assertions']
        assert sum(case.find('error') is not None for case in cases) == counts['errors']
        assert all(case.find('failure') is None and case.find('skipped') is None for case in cases)
    for file in sorted(directory.iterdir()):
        assert file.is_file()
        if result['process_exit'] != 0 and file.name in ['log.txt', 'junit.xml']:
            private.append({'path': str(file), 'sha256': sha(file.read_bytes()), 'reason': 'Failed original output retained privately; original result/counts remain public.'})
        else:
            members[str(file.relative_to(runtime))] = file.read_bytes()
    bundles.add(result['bundle'])
    outcomes.append({'name': name, 'source': command['source_before']['head'], 'result': result})
for bundle_name in sorted(bundles):
    directory = runtime / bundle_name
    identity = json.loads((directory / 'identity.json').read_text())
    manifest = json.loads((directory / 'manifest.json').read_text())
    assert sha(canonical(manifest)) == identity['manifest_sha256']
    assert sha((directory / 'runner.py').read_bytes()) == identity['runner_sha256']
    for file in sorted(directory.iterdir()):
        members[str(file.relative_to(runtime))] = file.read_bytes()

quality = ['focused-local-marker-old-original', 'focused-local-marker-fixed-original',
    'owned-file-final-pint-original', 'owned-file-final-focused-safeguards-original', 'owned-file-final-shard-policy-original',
    'owned-file-declared-shard-policy-original', 'owned-file-declared-cadence-original', 'owned-file-declared-native-discovery-original',
    'guards-all-datasets-list-original', 'guards-four-exact-datasets-list-original', 'owned-file-native-compatibility-selection-list-original']
for name in quality:
    for suffix in ['json', 'log']:
        file = runtime / (name + '.' + suffix)
        members[file.name] = file.read_bytes()
for name in ['owned-file-native-discovery-generated-originals.json', 'owned-file-native-discovery-generated-originals.zip', 'run-focused-local-declaration.py', 'prepare-standalone-mysql-owned-file.py', 'all-fixture-overrides-inventory-original.json', 'native-filter-interruption-original.json', 'guards-four-entrypoints-exact-filter.txt', 'stop-owned-file-mysql-and-reconcile.py', 'seal-owned-file-and-local-evidence.py']:
    file = runtime / name
    members[name] = file.read_bytes()
for name in ['server-start-owned-file.json', 'server-version-owned-file.json', 'server-owned-file-final-shutdown.json', 'owned-file-stop-reconciliation.json', 'owned-file-stop-first-reconciliation-failed.json']:
    file = runtime / 'mysql-standalone' / name
    members['mysql-standalone/' + name] = file.read_bytes()
for stem, dated in [('fixture-admission-owned-file-and-local-contract-review', '20261015'), ('fixture-admission-owned-file-source-review-d2cc2416', '20261015'), ('fixture-admission-owned-file-policy-carry-936a5c50', '20261016')]:
    for suffix in ['md', 'json']:
        source = Path('/tmp') / (stem + '-' + dated + '.' + suffix)
        destination = packet / (stem.replace('fixture-admission-', 'independent-') + '.' + suffix)
        assert not destination.exists()
        destination.write_bytes(source.read_bytes())

changed = subprocess.check_output(['git', 'diff', '--name-only', '27b998fe', '936a5c50'], cwd=root, text=True).splitlines()
source_bindings = []
for head in sorted({outcome['source'] for outcome in outcomes}):
    for name in changed:
        data = blob(head, name)
        archive_name = 'source/' + head + '/' + name
        members[archive_name] = data
        source_bindings.append({'head': head, 'path': name, 'sha256': sha(data), 'archive_name': archive_name})
old_proof = json.loads((runtime / 'source-carry-and-frozen-proof.json').read_text())
frozen = {}
for name in old_proof['actual_frozen_members_and_manifests']:
    actual = (root / name).read_bytes()
    assert actual == blob('f3b00476218e54f45ad1ee435e0fc5de115d717b', name)
    frozen[name] = sha(actual)
archive = packet / 'owned-file-and-local-evidence.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
    for name, data in sorted(members.items()):
        zipped.writestr(name, data)
index = {'archive_sha256': sha(archive.read_bytes()), 'archive_bytes': archive.stat().st_size,
    'members': [{'name': name, 'sha256': sha(data)} for name, data in sorted(members.items())],
    'original_php_invocations': outcomes, 'bundles': sorted(bundles), 'source_bindings': source_bindings,
    'private_originals': private, 'frozen_members_and_manifests_equal_pr130': frozen,
    'limits': 'Owned file restore/all current SQLite selected files and exact local/noCI + actualCI focused controls are source-bound completed scopes. Native Guards is only four exact representative datasets, NOT whole file or native SQLite DDL/rollback proof. Accidentally expanded native15-case filter was interrupted: PHP-15/recorder1/empty XML/NULLcounts, not a partial pass. Corrected listing proves exactly4 selected before restart. Original oldrestore5/E5, ONEold nativeadapter1/E1, firstnew31/E1 and localmissing/wrong1/E1 remain failed; pure controls53/1fail and52/1fail retained. Later936a changes ONEhelper-policyinput only, no full manifest equality claim. Native90-second lifecycle/fullF2/25counterparts/rawworkers/host/activation/release remain open.'}
with (packet / 'owned-file-and-local-index.json').open('x') as stream:
    json.dump(index, stream, indent=2)
    stream.write('\n')
print(json.dumps({'members': len(members), 'original_php_invocations': len(outcomes), 'private_originals': len(private), 'archive_sha256': index['archive_sha256']}, indent=2))
