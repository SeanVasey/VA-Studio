#!/usr/bin/env python3
import argparse,datetime,json,os,subprocess,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--stage',choices=['initialize','start','ready','stop'],required=True);a=p.parse_args()
r=Path('/tmp/fixture-admission-mysql-runtime-20261015');out=Path('/tmp/fixture-admission-evidence-20261015/mysql-standalone');out.mkdir(exist_ok=True)
d=Path('/tmp/va-studio-fixture-admission-mysql-data-standalone-20261015');sock=Path('/tmp/va-studio-fixture-admission-mysql-socket-standalone-20261015');env={**os.environ,'LD_LIBRARY_PATH':str(r/'lib')}
binary=str(r/'mysqld');database='vaseyaudio_fixture_admission'
def record(name,argv,timeout=120):
 result=subprocess.run(argv,env=env,capture_output=True,text=True,timeout=timeout)
 value={'argv':argv,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
 with (out/(name+'.json')).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 print(name,result.returncode);result.check_returncode();return result
base=[binary,'--no-defaults','--basedir='+str(r),'--datadir='+str(d)]
if a.stage=='initialize':
 assert not d.exists() and not sock.exists();d.mkdir(mode=0o700);sock.mkdir(mode=0o700)
 record('initialize',base+['--initialize-insecure','--log-error='+str(out/'initialize.log')])
elif a.stage=='start':
 record('server-start-v2',base+['--secure-file-priv=NULL','--daemonize','--bind-address=127.0.0.1','--port=33524','--socket='+str(sock/'mysql.sock'),'--mysqlx=OFF','--performance-schema=ON','--innodb-buffer-pool-size=64M','--max-connections=20','--default-time-zone=+00:00','--pid-file='+str(out/'mysqld.pid'),'--log-error='+str(out/'server.log')])
elif a.stage=='ready':
 assert (sock/'mysql.sock').exists()
 code='$p=new PDO("mysql:unix_socket='+str(sock/'mysql.sock')+'","root","");$p->exec("CREATE DATABASE '+database+' CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");echo json_encode($p->query("SELECT VERSION() AS version, DATABASE() AS current_schema, @@socket AS socket, @@port AS port, @@bind_address AS bind_address")->fetch(PDO::FETCH_ASSOC));'
 record('schema-create',['php','-r',code])
 code='$p=new PDO("mysql:unix_socket='+str(sock/'mysql.sock')+';dbname='+database+'","root","");echo json_encode($p->query("SELECT VERSION() AS version, DATABASE() AS current_schema, @@socket AS socket, @@port AS port, @@bind_address AS bind_address, @@session.time_zone AS time_zone, @@session.sql_mode AS sql_mode")->fetch(PDO::FETCH_ASSOC));'
 record('server-version',['php','-r',code])
elif a.stage=='stop':
 code='$p=new PDO("mysql:unix_socket='+str(sock/'mysql.sock')+';dbname='+database+'","root","");$p->exec("SHUTDOWN");'
 record('server-shutdown',['php','-r',code])
