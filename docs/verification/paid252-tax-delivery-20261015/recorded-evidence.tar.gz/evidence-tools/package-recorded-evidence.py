#!/usr/bin/env python3
"""Seal original recorded outcomes; preserve compiler/preparation failures as such."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import xml.etree.ElementTree as ET

root = Path('/workspace/VA-Studio-tax-v2-committed-read')
runtime = Path('/workspace/runtime/paid252-tax-delivery-evidence-20261015')
packet = root / 'docs/verification/paid252-tax-delivery-20261015'
oracles = {'sqlite-four-source-oracles-corrected-fixtures'}
harness = {
 'sqlite-download-adversarial-first': 'Fixture decrypt hook ran in outside-transaction locator; refusal succeeded but rollback assertion was wrong. Stopped6/89/F1; later cases unexecuted.',
 'sqlite-key-owner-mutation-diagnostic': 'Original diagnostic confirms first mutation at PDO false/framework0 in locator.1/11/F1; fixture target corrected, not producer rollback repair.',
 'sqlite-four-real-source-oracles-before-repair': 'Mixed original5/13/F4/E1: genuine recent-set and pending-admission failures; ineffective cached-instance resolver fixture, key expected-status error, and missing unpublish in replacement-media fixture. Not the complete four-oracle proof.',
}
unresolved_failures = {}
product_failures = {}
preparations = set()
foreground = set()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

assert git('status', '--porcelain') == b'', 'Freeze source before sealing.'
head = git('rev-parse', 'HEAD').decode().strip()
members, blobs, inventories, invocations, preparatory = {}, {}, {}, [], []

def include(path, name):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in members, name
    members[name] = path.read_bytes()

def bind_inventory(bundle):
    if bundle.name in inventories:
        return inventories[bundle.name]
    identity, manifest = read(bundle / 'identity.json'), read(bundle / 'manifest.json')
    assert sha(canonical(manifest)) == identity['manifest_sha256']
    assert sha(canonical(read(bundle / 'runtime.json'))) == identity['runtime_sha256']
    assert sha(canonical(read(bundle / 'public-environment.json'))) == identity['public_environment_sha256']
    assert sha((bundle / 'runner.py').read_bytes()) == identity['runner_sha256']
    proc = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=root,
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    try:
        for path, digest in manifest.items():
            proc.stdin.write((identity['head'] + ':' + path + '\n').encode())
            proc.stdin.flush()
            header = proc.stdout.readline().split()
            assert len(header) == 3 and header[1] == b'blob', (bundle.name, path)
            data = proc.stdout.read(int(header[2]))
            assert len(data) == int(header[2]) and proc.stdout.read(1) == b'\n'
            assert sha(data) == digest, (bundle.name, path)
            if digest in blobs:
                assert blobs[digest] == data
            else:
                blobs[digest] = data
    finally:
        proc.stdin.close()
        assert proc.wait() == 0
    for path in sorted(bundle.iterdir()):
        include(path, bundle.name + '/' + path.name)
    inventories[bundle.name] = {'identity': identity, 'manifest': manifest}
    return inventories[bundle.name]

names = sorted({p.stem.removeprefix('launch-') for p in runtime.glob('launch-*.json')} | foreground)
for name in names:
    launch_path = runtime / ('launch-' + name + '.json')
    run = runtime / name
    launch = read(launch_path) if launch_path.exists() else None
    if name in preparations:
        original = read(runtime / ('preparation-' + name + '.json'))
        assert original['launch'] == launch and original['observed_recorder_os_exit'] == 1
        assert original['original_log_sha256'] == sha((runtime / ('launch-' + name + '.log')).read_bytes())
        assert not (run / 'command.json').exists() and not (run / 'result.json').exists()
        assert list(run.iterdir()) == [], 'Preparation failure did not launch PHP.'
        preparatory.append(original)
        continue
    assert (run / 'result.json').is_file(), 'Active/incomplete run: ' + name
    command, result = read(run / 'command.json'), read(run / 'result.json')
    assert command['source_before'] == result['source_after']
    if launch is not None:
        assert launch['source'] == command['source_before']
    assert command['before_git_equal'] and command['overlays'] == []
    assert all(result[k] for k in ('source_unchanged', 'source_head_unchanged',
        'source_status_unchanged', 'runner_unchanged', 'autoload_unchanged'))
    assert result['log_sha256'] == sha((run / 'log.txt').read_bytes())
    assert int((run / 'process.exit').read_text()) == result['process_exit']
    witness = None
    if launch is not None:
        witness = read(runtime / ('observed-os-exit-' + name + '.json'))
        assert witness['pid'] == launch['pid'] and witness['process_start_ticks'] == launch['process_start_ticks']
        assert witness['state'] == 'Z' and witness['uid'] == launch['uid'] and witness['identity_matched']
        assert witness['observed_os_exit'] == result['verifier_exit']
    else:
        assert name in foreground
    counts = result['junit']
    if counts is None:
        assert name == 'old-reentrant-admission-gap' and result['process_exit'] == 255
        assert result['verifier_exit'] == 1 and (run / 'junit.xml').read_bytes() == b''
        assert result['junit_error'] is not None
    else:
        doc = ET.parse(run / 'junit.xml').getroot()
        top = doc if doc.tag == 'testsuite' else doc.find('testsuite')
        cases = list(doc.iter('testcase'))
        actual = {'tests': len(cases), 'assertions': sum(int(c.get('assertions', '0')) for c in cases),
                  'errors': sum(c.find('error') is not None for c in cases),
                  'failures': sum(c.find('failure') is not None for c in cases),
                  'skipped': sum(c.find('skipped') is not None for c in cases)}
        assert actual == counts == {k: int(top.get(k)) for k in actual}
        if name in oracles:
            assert counts['failures'] == 4 and counts['errors'] == counts['skipped'] == 0
            assert result['process_exit'] == result['verifier_exit'] == 1
        elif name in harness or name in product_failures or name in unresolved_failures:
            assert result['process_exit'] != 0 and result['verifier_exit'] == 1
            assert counts['failures'] + counts['errors'] > 0
        else:
            assert counts['failures'] == counts['errors'] == 0
            assert result['process_exit'] == result['verifier_exit'] == 0
    bundle = runtime / result['bundle']
    bound = bind_inventory(bundle)
    identity, manifest = bound['identity'], bound['manifest']
    assert identity['head'] == command['source_before']['head']
    assert identity['manifest_sha256'] == command['before_digest'] == result['after_digest']
    assert len(manifest) == command['source_input_count'] == result['source_input_count']
    # Every historical runner byte set is retained in its launch-bound bundle; it need not equal the later recorder.
    if launch is not None:
        assert identity['runner_sha256'] == launch['runner_sha256']
        launcher = runtime / ('launcher-' + launch['launcher_sha256'] + '.py')
        assert sha(launcher.read_bytes()) == launch['launcher_sha256']
    if counts is not None:
        policy_path = 'scripts/ci/database-sqlite-skips.json' if command['public_environment']['DB_CONNECTION'] == 'sqlite' else 'scripts/ci/database-mysql-skips.json'
        policy = json.loads(blobs[manifest[policy_path]])
        allowed = {tuple(x) for x in policy['methods']}
        skipped = [(c.get('class'), c.get('name').split(' with data set ', 1)[0])
                   for c in cases if c.find('skipped') is not None]
        current_allowed = {tuple(x) for x in read(root / policy_path)['methods']}
        assert all(pair in allowed or (name == 'sqlite-final-download-and-schema-files' and pair in current_allowed) for pair in skipped), (name, skipped)
        # be6 ran the actual three native skips before CI declaration294; preserve that fact, not a backdated policy.
    else:
        skipped = None
    for path in sorted(run.iterdir()):
        include(path, name + '/' + path.name)
    invocations.append({'name': name, 'head': identity['head'], 'bundle': bundle.name,
        'command': name + '/command.json', 'counts': counts, 'skipped_methods': skipped,
        'process_exit': result['process_exit'], 'verifier_exit': result['verifier_exit'],
        'observed_recorder_os_exit': None if witness is None else witness['observed_os_exit'],
        'os_evidence': 'Original foreground tool return only; no portable PID/startticks witness reconstructed.' if witness is None else 'Original launch-bound UID/startticks OS observation.',
        'scope': ('Four genuine old-source behavior failures with one passing held-key/owner control; all five selected cases executed.' if name in oracles
                  else harness.get(name, product_failures.get(name, unresolved_failures.get(name, 'Completed selected cases; no whole-suite/host/provider inference.'))))})

for path in sorted(runtime.iterdir()):
    if path.is_file():
        include(path, path.name)
for path in sorted(Path('/workspace/runtime').glob('paid252-tax-delivery-*-review-*-20261015.*')):
    if path.is_file() and path.suffix in ['.md', '.json'] and 'full-source-review' not in path.name:
        include(path, 'independent-originals/' + path.name)
# Exact private MySQL run/setup/stop commands are retained in original runtime JSON receipts.
include(Path(__file__), 'evidence-tools/package-recorded-evidence.py')
assert read(runtime / 'mysql-server-stop.json')['process_exit'] == 0
current = next(x for x in invocations if x['name'] == 'sqlite-affected-v1-paid-journeys')
manifest = inventories[current['bundle']]['manifest']
allowed_metadata = {'scripts/ci/database-mysql-selection.json', 'scripts/ci/database-mysql-skips.json', 'scripts/ci/database-sqlite-skips.json'}
changed_inputs = set(git('diff', '--name-only', current['head'], head, '--', *manifest).decode().splitlines())
assert changed_inputs == allowed_metadata, changed_inputs
final_manifest = {p: sha((root / p).read_bytes()) for p in manifest}
assert {p for p in manifest if final_manifest[p] != manifest[p]} == allowed_metadata
tracked = set(git('ls-files', '-z', '--cached').decode().split('\0'))
assert all(p in tracked for p in final_manifest)
for path, digest in final_manifest.items():
    data = git('show', head + ':' + path)
    assert sha(data) == digest
    blobs.setdefault(digest, data)
loaders = read(runtime / current['bundle'] / 'runtime.json')['autoload']
assert {p: sha((root / p).read_bytes()) for p in loaders} == loaders
final_inventory = {'head': head, 'manifest': final_manifest, 'manifest_sha256': sha(canonical(final_manifest)), 'autoload': loaders, 'runtime_scope': 'Current immutable source binding only; no PHP application rerun on this metadata-only successor.', 'historical_v1_run_head': current['head'], 'historical_input_changes': sorted(changed_inputs)}
members['final-candidate-source-inventory.json'] = json.dumps(final_inventory, indent=2, sort_keys=True).encode() + b'\n'
for digest, data in sorted(blobs.items()):
    members['source-blobs/' + digest] = data
index = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'candidate_head': head, 'last_executed_v1_selection_head': current['head'],
    'final_manifest_sha256': final_inventory['manifest_sha256'], 'metadata_only_input_changes_since_last_v1_run': sorted(changed_inputs),
    'invocations': invocations, 'preparation_failures': preparatory,
    'actual_php_process_launches': len(invocations),
    'executed_testcase_invocations': sum(x['counts'] is not None for x in invocations),
    'pre_php_preparation_failures': len(preparatory),
    'source_inventories': sorted(inventories), 'source_inventory_count': len(inventories),
    'source_blob_count': len(blobs), 'current_input_count': len(manifest),
    'route_input_count': sum(p.startswith('routes/') for p in manifest),
    'loader_hash_count': len(loaders),
    'source_blob_layout': 'Exact deduplicated Git blob bytes at source-blobs/<sha256>; inventory binds each repository path.',
    'member_sha256': {n: sha(b) for n, b in sorted(members.items())},
    'archive_member_count': len(members),
    'limits': 'Exact recorded source applies per invocation. Original behavioral/product, fixture, expectation, policy preparation and unresolved native barrier outcomes remain distinct. All current invocations have launch-bound recorder OS observations. Historical launcher bytes are reconstructed from retained predecessor with the recorded transform and match their original SHA; command/launch/outcomes stay original. Native components are narrow carries, not whole-current-head reruns. No Foundation/GitLab/host/provider/live/activation claim.'}
archive = packet / 'recorded-evidence.tar.gz'
assert not archive.exists() and not (packet / 'recorded-evidence-index.json').exists()
with archive.open('xb') as stream:
    with tarfile.open(fileobj=stream, mode='w:gz') as tar:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(members)
    for item in tar.getmembers():
        assert item.isfile() and sha(tar.extractfile(item).read()) == index['member_sha256'][item.name]
index['archive_sha256'], index['archive_bytes'] = sha(archive.read_bytes()), archive.stat().st_size
with (packet / 'recorded-evidence-index.json').open('x') as stream:
    json.dump(index, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({k: index[k] for k in ('candidate_head', 'actual_php_process_launches',
    'executed_testcase_invocations', 'pre_php_preparation_failures', 'source_inventory_count',
    'source_blob_count', 'archive_member_count', 'archive_sha256', 'archive_bytes')}, indent=2))
