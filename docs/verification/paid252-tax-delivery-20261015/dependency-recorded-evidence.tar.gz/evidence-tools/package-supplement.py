from pathlib import Path
import json,hashlib,subprocess,tarfile,io,datetime,xml.etree.ElementTree as ET
root=Path('/workspace/VA-Studio-tax-v2-committed-read');r=Path('/workspace/runtime/paid252-tax-delivery-dependency-evidence-20261015');pub=Path('/workspace/runtime/paid252-tax-delivery-publication-20261015');packet=root/'docs/verification/paid252-tax-delivery-20261015'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(o):return json.dumps(o,sort_keys=True,separators=(',',':')).encode()
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
assert git('status','--porcelain')==b''
head=git('rev-parse','HEAD').decode().strip();members={};blobs={};runs=[];inventories={}
def include(p,name):
 assert p.is_file() and not p.is_symlink() and name not in members
 members[name]=p.read_bytes()
allowed={tuple(p) for p in read(root/'scripts/ci/database-sqlite-skips.json')['methods']}
for n in ['sqlite-current-runtime-tax-and-http','sqlite-unfinished-storefront-and-root-with-testing-key']:
 launch=read(r/('launch-'+n+'.json'));command=read(r/n/'command.json');result=read(r/n/'result.json');witness=read(r/('observed-os-exit-'+n+'.json'));bundle=r/result['bundle'];identity=read(bundle/'identity.json');manifest=read(bundle/'manifest.json');runtime=read(bundle/'runtime.json')
 assert launch['source']==command['source_before']==result['source_after']
 assert all(result[k] for k in ['source_unchanged','source_head_unchanged','source_status_unchanged','runner_unchanged','autoload_unchanged'])
 assert command['before_git_equal'] and command['overlays']==[]
 assert identity['head']==command['source_before']['head']
 assert identity['manifest_sha256']==sha(canonical(manifest))==command['before_digest']==result['after_digest']
 assert identity['runner_sha256']==launch['runner_sha256']==sha((bundle/'runner.py').read_bytes())==sha(Path(launch['argv'][1]).read_bytes())
 assert any(sha(p.read_bytes())==launch['launcher_sha256'] for p in r.glob('launch-durable*.py'))
 assert sha(canonical(runtime))==identity['runtime_sha256']
 assert sha(canonical(read(bundle/'public-environment.json')))==identity['public_environment_sha256']
 assert result['log_sha256']==sha((r/n/'log.txt').read_bytes())
 assert result['process_exit']==int((r/n/'process.exit').read_text()) and result['verifier_exit']==witness['observed_os_exit']
 assert all(witness[k]==launch[k] for k in ['pid','uid','process_start_ticks']) and witness['identity_matched'] and witness['state']=='Z'
 cases=list(ET.parse(r/n/'junit.xml').iter('testcase'));counts={'tests':len(cases),'assertions':sum(int(c.get('assertions','0')) for c in cases),'failures':sum(c.find('failure') is not None for c in cases),'errors':sum(c.find('error') is not None for c in cases),'skipped':sum(c.find('skipped') is not None for c in cases)};assert counts==result['junit']
 if n=='sqlite-current-runtime-tax-and-http':
  assert counts=={'tests':72,'assertions':3261,'failures':0,'errors':1,'skipped':3} and result['process_exit']==2 and result['verifier_exit']==1
  bad=[c for c in cases if c.find('error') is not None];assert len(bad)==1 and bad[0].get('class')=='Tests\\Feature\\StorefrontMetadataTest' and 'MissingAppKeyException' in bad[0].find('error').text
 else:assert counts=={'tests':14,'assertions':227,'failures':0,'errors':0,'skipped':0} and result['process_exit']==result['verifier_exit']==0
 skips=[(c.get('class'),c.get('name')) for c in cases if c.find('skipped') is not None];assert all((cls,name.split(' with data set ',1)[0]) in allowed for cls,name in skips)
 assert git('diff','--name-only',identity['head'],head,'--',*manifest).strip()==b''
 if bundle.name not in inventories:
  proc=subprocess.Popen(['git','cat-file','--batch'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
  try:
   for path,digest in manifest.items():
    assert sha((root/path).read_bytes())==digest
    proc.stdin.write((identity['head']+':'+path+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().split();assert len(header)==3 and header[1]==b'blob';data=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n' and sha(data)==digest;blobs[digest]=data
  finally:proc.stdin.close();assert proc.wait()==0
  inventories[bundle.name]=identity
 assert {p:sha((root/p).read_bytes()) for p in runtime['autoload']}==runtime['autoload']
 groups={}
 for c in cases:
  o=groups.setdefault(c.get('class'),{'tests':0,'assertions':0,'failures':0,'errors':0,'skipped':0});o['tests']+=1;o['assertions']+=int(c.get('assertions','0'))
  for k,t in [('failures','failure'),('errors','error'),('skipped','skipped')]:o[k]+=c.find(t) is not None
 runs.append({'name':n,'executed_head':identity['head'],'bundle':bundle.name,'counts':counts,'class_components':groups,'skipped_cases':skips,'php_exit':result['process_exit'],'recorder_exit':result['verifier_exit'],'observed_os_exit':witness['observed_os_exit']})
for p in r.rglob('*'):
 if p.is_file():include(p,str(p.relative_to(r)))
for name in ['composer-audit-local-before','composer-minimal-update','composer-supported-update','composer-audit-supported','composer-validate-supported','composer-platform-supported','failed-preflight-final','readiness-initial-final','foundation-upstream-compare']:
 include(pub/(name+'.json'),'preflight-and-dependency-originals/'+name+'.json')
original=read(pub/'failed-preflight-log.json');redacted={k:v for k,v in original.items() if k!='stderr'};redacted.update({'stderr':'failed to get run log: temporary GitHub Actions redirect returned Forbidden (expiring URL omitted).','original_receipt_sha256':sha((pub/'failed-preflight-log.json').read_bytes()),'scope':'Redacted derivative, not original bytes. Exact original remains host-only.'});members['preflight-and-dependency-originals/log-access-redacted.json']=json.dumps(redacted,indent=2).encode()+b'\n'
log=(pub/'backend-quality-original.log').read_text();lines=log.splitlines();ix=next(i for i,l in enumerate(lines) if '##[group]Run composer audit' in l);end=next(i for i in range(ix,len(lines)) if 'Process completed with exit code 1.' in lines[i]);excerpt='\n'.join(lines[ix:end+1])+'\n';members['preflight-and-dependency-originals/audit-job-excerpt.log']=excerpt.encode();members['preflight-and-dependency-originals/audit-log-provenance.json']=json.dumps({'job_id':116368056191,'run_id':38718687265,'actual_full_log_sha256':sha((pub/'backend-quality-original.log').read_bytes()),'excerpt_sha256':sha(excerpt.encode()),'scope':'Actual GitHub connector job log fetched after direct gh download403. Full original stays host-only; this exact excerpt records the enforced audit failure.'},indent=2).encode()+b'\n'
for p in sorted(Path('/workspace/runtime').glob('paid252-tax-delivery-foundation-*review*-20261015.*')):
 if p.suffix in ['.md','.json']:include(p,'independent-originals/'+p.name)
include(Path(__file__),'evidence-tools/package-supplement.py')
for h,data in blobs.items():members['source-blobs/'+h]=data
index={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_head':head,'invocations':runs,'actual_php_process_launches':len(runs),'source_inventory_count':len(inventories),'source_input_count':len(manifest),'source_blob_count':len(blobs),'route_input_count':sum(p.startswith('routes/') for p in manifest),'loader_hash_count':len(runtime['autoload']),'archive_member_count':len(members),'member_sha256':{name:sha(data) for name,data in sorted(members.items())},'scope':'Original failed eight-file current-runtime72/3261/E1/S3 invocation preserves complete six-file71/3261/E0/S3 components. Fresh whole unfinished two-file14/227/E0/S0 continuation uses host-only synthetic testing key. No fabricated green whole-eight-file invocation; previous thirteen originals/native old-runtime results remain separate. No current-native/whole-runtime equality/full/host/Foundation/GitLab claim.'}
archive=packet/'dependency-recorded-evidence.tar.gz';dest=packet/'dependency-recorded-evidence-index.json';assert not archive.exists() and not dest.exists()
with archive.open('xb') as f:
 with tarfile.open(fileobj=f,mode='w:gz') as tar:
  for name,data in sorted(members.items()):
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(members)
 for m in tar.getmembers():assert m.isfile() and sha(tar.extractfile(m).read())==index['member_sha256'][m.name]
index.update({'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size})
with dest.open('x') as f:json.dump(index,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({k:index[k] for k in ['candidate_head','actual_php_process_launches','source_inventory_count','source_input_count','source_blob_count','archive_member_count','archive_sha256','archive_bytes']},indent=2))
