#!/usr/bin/env python3
"""Seal original closed Tax V2 focused receipts; refuse active/incomplete records."""
import datetime
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import xml.etree.ElementTree as ET

root = Path('/workspace/VA-Studio-tax-v2-integration')
runtime = Path('/workspace/runtime/tax-v2-integration-evidence-20261014')
packet = root / 'docs/verification/tax-v2-integration-20261014'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def git_inputs(head, names):
    found = {}
    proc = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=root, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    try:
        for name in names:
            proc.stdin.write((head + ':' + name + '\n').encode()); proc.stdin.flush()
            header = proc.stdout.readline().split()
            assert len(header) == 3 and header[1] == b'blob', (head, name)
            content = proc.stdout.read(int(header[2])); assert proc.stdout.read(1) == b'\n'
            found[name] = sha(content)
    finally:
        proc.stdin.close(); assert proc.wait() == 0
    return found

assert not git('status', '--porcelain'), 'Freeze candidate before packaging'
members = {}
def include(path, name=None):
    relative = name or str(path.relative_to(runtime))
    assert relative not in members
    members[relative] = path.read_bytes()

invocations = []
bundles = set()
launches = sorted(runtime.glob('launch-*.json'))
assert len(launches) == 4, 'Expected two original failures and two completed current selections'
for launch_file in launches:
    launch = read(launch_file)
    name = launch_file.name.removeprefix('launch-').removesuffix('.json')
    run = runtime / name
    assert (run / 'result.json').is_file(), 'Active or incomplete run: ' + name
    command, result = read(run / 'command.json'), read(run / 'result.json')
    assert int((run / 'process.exit').read_text()) == result['process_exit']
    assert result['source_unchanged'] and result['source_head_unchanged'] and result['source_status_unchanged']
    assert result['runner_unchanged'] and result['autoload_unchanged']
    assert launch['source'] == command['source_before'] == result['source_after']
    assert command['before_git_equal'] and command['overlays'] == []
    assert result['log_sha256'] == sha((run / 'log.txt').read_bytes())
    document = ET.parse(run / 'junit.xml').getroot()
    top = document.find('testsuite') if document.tag != 'testsuite' else document
    cases = list(document.iter('testcase'))
    counts = {'tests': len(cases), 'assertions': sum(int(c.get('assertions', '0')) for c in cases),
              'errors': sum(c.find('error') is not None for c in cases),
              'failures': sum(c.find('failure') is not None for c in cases),
              'skipped': sum(c.find('skipped') is not None for c in cases)}
    assert counts == result['junit'] == {k: int(top.get(k)) for k in counts}
    expected_failure = name.endswith('-old-source')
    assert counts['errors'] == counts['skipped'] == 0
    assert result['process_exit'] == result['verifier_exit'] == (1 if expected_failure else 0)
    assert counts['failures'] == (1 if expected_failure else 0)
    bundle = runtime / result['bundle']; identity = read(bundle / 'identity.json'); manifest = read(bundle / 'manifest.json')
    assert command['bundle'] == bundle.name
    assert identity['head'] == command['source_before']['head']
    assert identity['manifest_sha256'] == command['before_digest'] == result['after_digest'] == sha(canonical(manifest))
    assert result['source_input_count'] == command['source_input_count'] == len(manifest)
    assert manifest == git_inputs(identity['head'], manifest)
    assert identity['runtime_sha256'] == sha(canonical(read(bundle / 'runtime.json')))
    assert identity['public_environment_sha256'] == sha(canonical(read(bundle / 'public-environment.json')))
    assert identity['runner_sha256'] == launch['runner_sha256'] == sha((bundle / 'runner.py').read_bytes())
    assert launch['launcher_sha256'] == sha((runtime / 'launch-durable.py').read_bytes())
    for path in sorted(run.iterdir()):
        assert path.is_file(); include(path)
    include(launch_file); include(runtime / ('launch-' + name + '.log'))
    bundles.add(bundle.name)
    invocations.append({'name': name, 'head': identity['head'], 'bundle': bundle.name,
                        'command': name + '/command.json', 'process_exit': result['process_exit'],
                        'verifier_exit': result['verifier_exit'], 'counts': counts,
                        'scope': 'Original behavioral failure' if expected_failure else 'Focused current-source selection'})

for name in sorted(bundles):
    for path in sorted((runtime / name).iterdir()):
        assert path.is_file(); include(path)
for name in ('run-focused.py', 'launch-durable.py', 'recorder-tools.json', 'mysql-server-launch.json',
             'mysql-server-ready.json', 'mysql-server-stop.json', 'recorder-os-exit-observations.json',
             'pint-128f423d.json', 'pint-128f423d-reconciled.json'):
    include(runtime / name)
review = Path('/workspace/runtime/tax-v2-independent-source-review-128f423d-20261014.md')
assert sha(review.read_bytes()) == 'ae97e289da205cccb8eb21ec6c0a1ae9ea562040e5a45092a56cd088d5aa926b'
include(review, 'independent-source-review.md')
include(Path(__file__), 'evidence-tools/package-recorded-evidence.py')
old_pint, pint = read(runtime / 'pint-128f423d.json'), read(runtime / 'pint-128f423d-reconciled.json')
assert old_pint['process_exit'] == 127 and pint['process_exit'] == 0
assert old_pint['before'] == old_pint['after'] == pint['before'] == pint['after']
assert read(runtime / 'mysql-server-stop.json')['process_exit'] == 0
os_exits = read(runtime / 'recorder-os-exit-observations.json')
assert len(os_exits) == len(invocations)
for record in invocations:
    witness = next(x for x in os_exits if x['name'] == record['name'])
    assert witness['identity_matches'] and witness['observed_recorder_exit'] == record['verifier_exit']
head = git('rev-parse', 'HEAD').decode().strip()
current = read(runtime / 'sqlite-tax-v2-affected/result.json')
manifest = read(runtime / current['bundle'] / 'manifest.json')
assert git_inputs(head, manifest) == manifest
assert {p: sha((root / p).read_bytes()) for p in manifest} == manifest
loaders = read(runtime / current['bundle'] / 'runtime.json')['autoload']
assert {p: sha((root / p).read_bytes()) for p in loaders} == loaders
index = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'candidate_head': head, 'invocations': invocations, 'actual_phpunit_invocations': len(invocations),
         'source_bundles': sorted(bundles), 'source_bundle_count': len(bundles),
         'current_input_count': len(manifest), 'route_input_count': sum(p.startswith('routes/') for p in manifest),
         'loader_hash_count': len(loaders), 'member_sha256': {n: sha(b) for n, b in sorted(members.items())},
         'archive_member_count': len(members),
         'limits': 'Overlapping focused selections, not full acceptance. Original failures and missing initial SQL receipt preserved. Formatting records are not PHPUnit invocations. No Foundation/GitLab/host/provider/live claim.'}
archive = packet / 'recorded-evidence.tar.gz'
assert not archive.exists() and not (packet / 'recorded-evidence-index.json').exists()
with archive.open('xb') as stream:
    with tarfile.open(fileobj=stream, mode='w:gz') as tar:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644; info.mtime = 0
            tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(members)
    for item in tar.getmembers():
        assert item.isfile() and item.name in members
        assert sha(tar.extractfile(item).read()) == index['member_sha256'][item.name]
index['archive_sha256'] = sha(archive.read_bytes()); index['archive_bytes'] = archive.stat().st_size
with (packet / 'recorded-evidence-index.json').open('x') as stream:
    json.dump(index, stream, indent=2, sort_keys=True); stream.write('\n')
print(json.dumps({k: index[k] for k in ('candidate_head', 'actual_phpunit_invocations', 'source_bundle_count', 'archive_member_count', 'archive_sha256', 'archive_bytes')}, indent=2))
