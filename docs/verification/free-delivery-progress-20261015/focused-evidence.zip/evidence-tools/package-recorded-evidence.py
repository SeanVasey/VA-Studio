#!/usr/bin/env python3
"""Seal closed D1 focused originals, with raw failed logs/XML retained privately by hash."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

root = Path('/workspace/VA-Studio-tax-v2-committed-read')
runtime = Path('/workspace/runtime/free-delivery-progress-evidence-20261015')
packet = root / 'docs/verification/free-delivery-progress-20261015'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
git = lambda *argv: subprocess.check_output(['git', *argv], cwd=root)
canonical = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':')).encode()
assert not git('status', '--porcelain')
head = git('rev-parse', 'HEAD').decode().strip()
members = {}
def include(path, name=None):
    name = name or str(path.relative_to(runtime))
    assert name not in members
    members[name] = path.read_bytes()

def git_hashes(commit, paths):
    result = {}
    proc = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=root, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    try:
        for path in paths:
            proc.stdin.write((commit + ':' + path + '\n').encode()); proc.stdin.flush()
            fields = proc.stdout.readline().split()
            assert len(fields) == 3 and fields[1] == b'blob', (commit, path)
            data = proc.stdout.read(int(fields[2])); assert proc.stdout.read(1) == b'\n'
            result[path] = sha(data)
    finally:
        proc.stdin.close(); assert proc.wait() == 0
    return result

names = ['returning-progress-old-original', 'returning-progress-old-complete-original',
         'zero-base-old-original', 'account-spool-old-original', 'returning-progress-account-fixed-original',
         'affected-free-sqlite-initial-original', 'shrink-clock-old-original',
         'progress-account-process-fixed-original', 'affected-free-sqlite-fixed-original',
         'account-domain-native-fixed-original']
bundles, invocations, private = set(), [], []
for name in names:
    run = runtime / name
    assert (run / 'result.json').is_file(), 'Active or incomplete run: ' + name
    command, result = read(run / 'command.json'), read(run / 'result.json')
    assert result['source_unchanged'] and result['source_head_unchanged'] and result['source_status_unchanged']
    assert result['runner_unchanged'] and result['autoload_unchanged']
    assert command['source_before'] == result['source_after'] and command['before_git_equal'] and command['overlays'] == []
    assert int((run / 'process.exit').read_text()) == result['process_exit']
    assert sha((run / 'log.txt').read_bytes()) == result['log_sha256']
    document = ET.parse(run / 'junit.xml').getroot()
    top = document if document.tag == 'testsuite' else document.find('testsuite')
    cases = list(document.iter('testcase'))
    counts = dict(tests=len(cases), assertions=sum(int(c.get('assertions', '0')) for c in cases),
                  failures=sum(c.find('failure') is not None for c in cases),
                  errors=sum(c.find('error') is not None for c in cases), skipped=sum(c.find('skipped') is not None for c in cases))
    assert counts == result['junit'] == {k: int(top.get(k)) for k in counts}
    bundle = runtime / result['bundle']; identity = read(bundle / 'identity.json'); manifest = read(bundle / 'manifest.json')
    assert identity['head'] == command['source_before']['head']
    assert identity['manifest_sha256'] == command['before_digest'] == result['after_digest'] == sha(canonical(manifest))
    assert len(manifest) == command['source_input_count'] == result['source_input_count']
    assert manifest == git_hashes(identity['head'], manifest)
    assert identity['runtime_sha256'] == sha(canonical(read(bundle / 'runtime.json')))
    assert identity['public_environment_sha256'] == sha(canonical(read(bundle / 'public-environment.json')))
    assert identity['runner_sha256'] == sha((bundle / 'runner.py').read_bytes())
    bundles.add(bundle.name)
    for filename in ['command.json', 'result.json', 'process.exit']:
        include(run / filename)
    if result['process_exit'] == 0:
        assert result['verifier_exit'] == counts['failures'] == counts['errors'] == counts['skipped'] == 0
        include(run / 'junit.xml'); include(run / 'log.txt')
    else:
        assert result['verifier_exit'] == 1
        for filename in ['junit.xml', 'log.txt']:
            data = (run / filename).read_bytes()
            private.append(dict(path=str(run / filename), bytes=len(data), sha256=sha(data), reason='Original failed output may contain synthetic private identity or configuration dumps; retained privately, not copied into Git.'))
        members[name + '/derived-case-outcomes.json'] = (json.dumps([
            dict(name=c.get('name'), class_name=c.get('class'), assertions=int(c.get('assertions', '0')),
                 outcome='error' if c.find('error') is not None else 'failure' if c.find('failure') is not None else 'skip' if c.find('skipped') is not None else 'pass')
            for c in cases], indent=2) + '\n').encode()
    invocations.append(dict(name=name, head=identity['head'], bundle=bundle.name, counts=counts,
                            process_exit=result['process_exit'], recorder_exit=result['verifier_exit'], command=name+'/command.json'))

for name in sorted(bundles):
    for path in sorted((runtime / name).iterdir()):
        assert path.is_file(); include(path)
for path in sorted(runtime.glob('*.json')):
    include(path)
for name in ['run-quality.py', 'run-focused-native-tmp.py', 'focused-pint-original.log', 'shard-policy-original.log',
             'native-selection-census-original.log', 'native-selection-census-corrected-original.log']:
    include(runtime / name)
for path in sorted((runtime / 'native-discovery-generated').iterdir()):
    include(path)
for name in ['prepare-free-delivery-progress-mysql-20261015.py', 'prepare-free-delivery-progress-mysql-tmp-20261015.py']:
    include(Path('/workspace/runtime') / name, 'evidence-tools/' + name)
for path in sorted((runtime / 'mysql-tmp-retry').glob('*.json')):
    include(path)
assert read(runtime / 'mysql-tmp-retry/mysql-server-stop.json')['process_exit'] == 0
assert read(runtime / 'mysql-tmp-retry/mysql-stopped-state.json')['state']['ExitCode'] == 0
for name in ['free-delivery-progress-design-20261015', 'free-delivery-progress-design-v2-20261015',
             'free-delivery-progress-design-review-20261015', 'free-delivery-progress-design-review-v2-20261015',
             'free-delivery-progress-source-review-f1d5fb1f-20261015', 'free-delivery-progress-source-review-2e071ef9-20261015',
             'free-delivery-identity-dependency-review-20261015']:
    for extension in ['md', 'json']:
        path = Path('/workspace/runtime') / (name + '.' + extension)
        if path.is_file(): include(path, 'independent/' + path.name)
include(Path(__file__), 'evidence-tools/package-recorded-evidence.py')
current = read(runtime / 'affected-free-sqlite-fixed-original/result.json')
manifest = read(runtime / current['bundle'] / 'manifest.json')
assert git_hashes(head, manifest) == manifest
assert {p: sha((root / p).read_bytes()) for p in manifest} == manifest
loaders = read(runtime / current['bundle'] / 'runtime.json')['autoload']
assert {p: sha((root / p).read_bytes()) for p in loaders} == loaders
changed = git('diff', '--name-only', '83901a60e4855f934d229ea1aaffe0796b07c8d2', head).decode().splitlines()
paths = [p for p in changed if p.startswith(('app/', 'tests/'))]
bindings = []
for commit in sorted({r['head'] for r in invocations}):
    for path in paths:
        query = subprocess.run(['git', 'cat-file', '-e', commit+':'+path], cwd=root, capture_output=True)
        if query.returncode != 0: continue
        data = git('show', commit+':'+path)
        blob = git('rev-parse', commit+':'+path).decode().strip()
        name = 'source/' + commit + '/' + path
        members[name] = data
        bindings.append(dict(head=commit, path=path, blob=blob, sha256=sha(data), member=name))
index = dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), candidate_head=head,
             invocations=invocations, original_phpunit_invocations=len(invocations), bundles=sorted(bundles),
             private_originals=private, git_bindings=bindings, current_input_count=len(manifest), loader_hash_count=len(loaders),
             members={name:sha(data) for name,data in sorted(members.items())}, archive_member_count=len(members),
             limits='Focused overlapping selections are not summed. Raw failed logs/XML hash-bound privately; every failure retained. POSIX process proof is local filesystem only; native selected domain case only. No full CI/host/provider/HTTP mount/blocked-write/activation/release claim.')
packet.mkdir(exist_ok=True)
archive = packet / 'focused-evidence.zip'
assert not archive.exists() and not (packet / 'focused-evidence-index.json').exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as zipped:
    for name,data in sorted(members.items()): zipped.writestr(name,data)
with zipfile.ZipFile(archive) as zipped:
    assert len(zipped.namelist()) == len(members)
    assert {n:sha(zipped.read(n)) for n in zipped.namelist()} == index['members']
index['archive_sha256'] = sha(archive.read_bytes()); index['archive_bytes'] = archive.stat().st_size
with (packet / 'focused-evidence-index.json').open('x') as output:
    json.dump(index,output,indent=2,sort_keys=True); output.write('\n')
print(json.dumps({k:index[k] for k in ['candidate_head','original_phpunit_invocations','archive_member_count','archive_sha256','archive_bytes']},indent=2))
