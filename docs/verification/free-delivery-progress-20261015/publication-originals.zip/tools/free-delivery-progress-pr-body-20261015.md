Free256 now enforces minimum returning-write progress from the original transfer start and permits at most one held snapshot per server-proved account across roles and origins. The final returning callback must meet both progress and the absolute deadline. Admission also inspects held slots above a newly reduced allocation count; invalid clocks and unknown held account metadata refuse before more bytes are copied.

This is a bounded A6-2 prerequisite. The HTTP mount, interruption of a blocked consumer, host send timeout/proxy behavior, source adapter, fonts/renderer, first-byte/identity composition and activation conditions remain open. Frozen renderer members/manifests are unchanged. One stale MAIN dependency test reference was updated only after independent Free256 reassessment.

- Tested source: `2e071ef9b4783beb99336968a8b73cd76f7c9cf5`.
- Component/process SQLite: 27 tests / 85 assertions; seven affected SQLite files: 34 / 313; selected real Downloads account-limit counterpart on private MySQL 8.4.11: 1 / 10. Each has zero failures, errors or skips and PHP/recorder/observed-tool exits 0. Selections overlap and are not summed.
- Separate PHP processes prove local POSIX lease retention during fill/holding, reservation accounting, graceful close and explicit exit/reclamation. No deployed filesystem or MySQL concurrency claim.
- Focused Pint10files and shard-policy52checks pass. Discovery proves2423 selected native cases/232files of9097 discovered cases/673files; discovery does not execute tests.
- Original failed tests and the empty initial MySQL disk-space failure are preserved. The successful private server stopped normally; its datadir is retained. All ten original PHP invocations are sealed in [the evidence packet](https://github.com/SeanVasey/VA-Studio/blob/01e429b9f2c2831e575b2e899d6a8ec49f1c8718/docs/verification/free-delivery-progress-20261015/README.md).

Independent source and final evidence decisions name their reviewed commits in that packet. Publication requires the exact-head carry, green cheap preflight, complete current review/check inventory and expected-SHA merge. No Foundation/GitLab dispatch or live/host/provider/deployment action.
