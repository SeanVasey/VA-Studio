import argparse
import datetime
import json
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--head', required=True)
p.add_argument('--pr', type=int, required=True)
p.add_argument('--run', type=int, required=True)
p.add_argument('--cancelled-run', type=int)
p.add_argument('--carry', required=True)
a = p.parse_args()
root = Path('/workspace/VA-Studio-tax-v2-committed-read')
out = Path('/workspace/runtime/free-delivery-progress-publication-20261015')
def read(name):
    d = json.loads((out / (name+'.json')).read_text())
    assert d['exit'] == 0
    return json.loads(d['stdout'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == a.head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
run = read('final-preflight')
assert run['headSha'] == a.head and run['databaseId'] == a.run
assert run['status'] == 'completed' and run['conclusion'] == 'success'
jobs = {'scope':'success','frontend':'success','backend-quality':'success','documentation':'skipped','Development preflight result':'success'}
assert {j['name']:j['conclusion'] for j in run['jobs']} == jobs
pr = read('final-inventory')['data']['repository']['pullRequest']
assert pr['number'] == a.pr and pr['headRefOid'] == a.head
assert pr['baseRefOid'] == '83901a60e4855f934d229ea1aaffe0796b07c8d2'
assert not pr['isDraft'] and pr['mergeable'] == 'MERGEABLE' and pr['mergeStateStatus'] == 'CLEAN'
for key in ['reviews','reviewThreads']:
    assert not pr[key]['pageInfo']['hasNextPage']
assert all(r['state'] in ['COMMENTED','APPROVED','DISMISSED'] for r in pr['reviews']['nodes'])
for thread in pr['reviewThreads']['nodes']:
    assert not thread['comments']['pageInfo']['hasNextPage']
    assert thread['isResolved'], 'Unresolved thread requires explicit P2 triage and a bounded whitelist; do not silently admit.'
contexts = pr['statusCheckRollup']['contexts']
assert not contexts['pageInfo']['hasNextPage']
for context in contexts['nodes']:
    assert context.get('status') in [None,'COMPLETED']
    if a.cancelled_run and ('/actions/runs/'+str(a.cancelled_run)+'/') in context.get('detailsUrl',''):
        assert context['conclusion'] in ['SUCCESS','SKIPPED','CANCELLED','FAILURE']
        continue
    assert context.get('conclusion',context.get('state')) in ['SUCCESS','SKIPPED'], 'Every current/unknown context must pass.'
if a.cancelled_run:
    cancelled = read('ready-cancellation-completed')
    assert cancelled['headSha'] == a.head and cancelled['databaseId'] == a.cancelled_run
    assert cancelled['status'] == 'completed' and cancelled['conclusion'] == 'cancelled'
    assert {j['name'] for j in cancelled['jobs']} == set(jobs)
    assert any(j['conclusion'] == 'cancelled' for j in cancelled['jobs'])
    for job in cancelled['jobs']:
        allowed = ['success','skipped','cancelled','failure'] if job['name'] == 'Development preflight result' else ['success','skipped','cancelled']
        assert job['conclusion'] in allowed, 'A genuine failed component of the cancelled run cannot be ignored.'
assert read('final-rules') == []
assert read('final-protection')['data']['repository']['defaultBranchRef']['branchProtectionRule'] is None
required = json.loads((out/'final-required-checks-corrected.json').read_text())
assert required['exit'] == 1 and 'no required checks reported' in required['stderr'].lower()
carry = json.loads(Path(a.carry).read_text())
assert carry['reviewed_sha'] == a.head and carry['open_p0'] == carry['open_p1'] == 0 and not carry['required_corrections']
record = dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),expected_head=a.head,
              pr=a.pr, preflight_run=a.run, preflight_jobs=jobs, readiness_cancelled_run=a.cancelled_run,
              review_count=len(pr['reviews']['nodes']),thread_count=len(pr['reviewThreads']['nodes']),
              context_count=len(contexts['nodes']), pagination_complete=True, independent_decision=carry['decision'],
              rules=[], branch_protection=None, scope='Focused development gate; exact identified readiness-cancellation artifact only, all current/unknown contexts pass. No settings change or bypass.')
with (out/'pre-merge-gate.json').open('x') as f:
    json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record,indent=2))
