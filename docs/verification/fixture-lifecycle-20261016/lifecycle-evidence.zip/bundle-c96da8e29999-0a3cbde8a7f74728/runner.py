#!/usr/bin/env python3
"""Fixture admission focused runner. Public receipts exclude environment secrets and artifacts."""
import argparse
import base64
import secrets
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from owned_child_observer_v4 import OwnedChildObserver

p = argparse.ArgumentParser()
p.add_argument('--name', required=True)
p.add_argument('--root', default='/tmp/VA-Studio-staff-mfa-leftovers-20261015')
p.add_argument('--output', default='/tmp/fixture-lifecycle-evidence-20261016')
p.add_argument('--driver', required=True, choices=['sqlite', 'mysql'])
p.add_argument('--database', default='vaseyaudio_account_features')
p.add_argument('--filter')
p.add_argument('--continue-on-defect', action='store_true')
p.add_argument('--timeout', type=int, default=1800)
p.add_argument('files', nargs='+')
a = p.parse_args()
root, output = Path(a.root).resolve(), Path(a.output).resolve()
output.mkdir(parents=True, exist_ok=True)
run = output / a.name
run.mkdir(exist_ok=False)
runner_bytes = Path(__file__).read_bytes()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def write_new(path, value):
    data = json.dumps(value, indent=2, sort_keys=True).encode() + b'\n'
    with path.open('xb') as stream:
        stream.write(data)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)

def source_state():
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'status': git('status', '--porcelain=v1').decode()}

def observed_inputs():
    tracked = set(git('ls-files', '-z', '--cached').decode().split('\0'))
    prefixes = ('app/', 'bootstrap/', 'config/', 'database/', 'resources/contracts/', 'routes/', 'scripts/', 'tests/')
    exact = {'composer.json', 'composer.lock', 'package.json', 'package-lock.json', 'phpunit.xml'}
    names = {n for n in tracked if n and (n.startswith(prefixes) or n in exact)}
    for directory in prefixes:
        for candidate in (root / directory).rglob('*'):
            if candidate.is_file() and '__pycache__' not in candidate.parts:
                names.add(str(candidate.relative_to(root)))
    paths = sorted({n for n in names if n and (n.startswith(prefixes) or n in exact)
                    and not n.startswith('bootstrap/cache/')})
    # Refuse undeclared local overlays, including ignored files, without reading their bytes.
    return {n: digest((root / n).read_bytes()) if n in tracked and (root / n).is_file() else None for n in paths}

def committed_inputs(head, names):
    result = {}
    proc = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=root,
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    try:
        for name in names:
            proc.stdin.write((head + ':' + name + '\n').encode())
            proc.stdin.flush()
            header = proc.stdout.readline().split()
            if len(header) != 3 or header[1] != b'blob':
                result[name] = None
                continue
            size = int(header[2])
            content = proc.stdout.read(size)
            if len(content) != size or proc.stdout.read(1) != b'\n':
                raise RuntimeError('Incomplete Git blob response')
            result[name] = digest(content)
    finally:
        proc.stdin.close()
        if proc.wait() != 0:
            raise RuntimeError('Git source binding failed')
    return result

def autoload_inputs():
    paths = [root / 'vendor/autoload.php', *sorted((root / 'vendor/composer').glob('*'))]
    return {str(q.relative_to(root)): digest(q.read_bytes()) for q in paths if q.is_file()}

def reconcile_junit(path):
    document = ET.parse(path).getroot()
    top = document if document.tag == 'testsuite' else document.find('testsuite')
    if top is None:
        raise ValueError('No top-level JUnit suite')
    cases = list(document.iter('testcase'))
    if not cases:
        raise ValueError('No executed testcases')
    counts = {k: int(top.attrib[k]) for k in ['tests', 'assertions', 'failures', 'errors', 'skipped']}
    actual = {'tests': len(cases), 'assertions': sum(int(c.get('assertions', '0')) for c in cases),
              'failures': sum(c.find('failure') is not None for c in cases),
              'errors': sum(c.find('error') is not None for c in cases),
              'skipped': sum(c.find('skipped') is not None for c in cases)}
    if counts != actual:
        raise ValueError('Suite/testcase totals differ: ' + repr((counts, actual)))
    return counts

state = source_state()
before = observed_inputs()
expected = committed_inputs(state['head'], before)
if before != expected or any(v is None for v in before.values()):
    write_new(run / 'setup-refusal.json', {'source': state, 'reason': 'Inputs differ from committed source',
              'differences': {k: [before.get(k), expected.get(k)] for k in before if before[k] != expected.get(k)}})
    raise SystemExit('Freeze all declared inputs before execution; refusal recorded.')
for selected in a.files:
    if selected not in before:
        raise SystemExit('Selected test is outside captured committed scope: ' + selected)

tmp = Path('/tmp/va-studio-fixture-lifecycle-tests-v4-20261016')
tmp.mkdir(mode=0o700, exist_ok=True)
if tmp.is_symlink() or not tmp.is_dir() or tmp.stat().st_uid != os.geteuid():
    raise SystemExit('Owned TMPDIR prerequisite refused')
env_delta = {'APP_ENV': 'testing', 'APP_DEBUG': 'false', 'DB_URL': '', 'DB_CONNECTION': a.driver,
             'DB_DATABASE': ':memory:' if a.driver == 'sqlite' else a.database,
             'DB_HOST': '127.0.0.1', 'DB_PORT': '33525',
             'DB_SOCKET': '' if a.driver == 'sqlite' else '/tmp/va-studio-fixture-lifecycle-mysql-socket-20261016/mysql.sock',
             'DB_USERNAME': 'root', 'DB_PASSWORD': '', 'CACHE_STORE': 'array',
             'SESSION_DRIVER': 'array', 'QUEUE_CONNECTION': 'sync', 'VA_LOCAL_DISPOSABLE_MYSQL': ':memory:' if a.driver == 'sqlite' else a.database, 'TMPDIR': str(tmp), 'LARAVEL_STORAGE_PATH': str(tmp / 'laravel-storage')}
# Host-only ephemeral testing key; never emit/archive the generated value.
env_delta['APP_KEY'] = 'base64:' + base64.b64encode(secrets.token_bytes(32)).decode()
(tmp / 'laravel-storage/framework/views').mkdir(parents=True, mode=0o700, exist_ok=True)
(tmp / 'laravel-storage/framework/testing').mkdir(parents=True, mode=0o700, exist_ok=True)
env = {**os.environ, **env_delta}
public_env = {k: v for k, v in env_delta.items() if k not in {'DB_USERNAME', 'DB_PASSWORD', 'APP_KEY'}}
public_env['synthetic_testing_app_key_configured'] = True
autoload_before = autoload_inputs()
runtime = {'php_binary': subprocess.check_output(['php','-r','echo PHP_BINARY;'],text=True), 'observer_sha256': digest(Path(__file__).with_name('owned_child_observer_v4.py').read_bytes()), 'php': subprocess.check_output(['php', '-v'], text=True),
           'phpunit': subprocess.check_output(['php', '-r', 'require "vendor/autoload.php"; '
             'exit((new PHPUnit\\TextUI\\Application)->run(["phpunit", "--version"]));'], cwd=root, text=True),
           'autoload': autoload_before, 'composer_lock_sha256': before['composer.lock']}
if a.driver == 'mysql':
    probe = '$p=new PDO("mysql:unix_socket=".getenv("DB_SOCKET").";dbname=".getenv("DB_DATABASE"),'
    probe += 'getenv("DB_USERNAME"),getenv("DB_PASSWORD")); echo json_encode('
    probe += '$p->query("SELECT VERSION() AS version, DATABASE() AS database_name")->fetch(PDO::FETCH_ASSOC));'
    runtime['database'] = json.loads(subprocess.check_output(['php', '-r', probe], env=env, text=True))
else:
    runtime['database'] = {'driver': 'sqlite', 'database_name': ':memory:',
        'version': subprocess.check_output(['php', '-r', 'echo (new PDO("sqlite::memory:"))->query("SELECT sqlite_version()")->fetchColumn();'], text=True)}

identity = {'head': state['head'], 'manifest_sha256': digest(canonical(before)),
            'runner_sha256': digest(runner_bytes), 'runtime_sha256': digest(canonical(runtime)),
            'public_environment_sha256': digest(canonical(public_env))}
bundle = output / ('bundle-' + state['head'][:12] + '-' + digest(canonical(identity))[:16])
if bundle.exists():
    if json.loads((bundle / 'identity.json').read_text()) != identity:
        raise SystemExit('Existing bundle identity differs')
    if (json.loads((bundle / 'manifest.json').read_text()) != before
            or json.loads((bundle / 'runtime.json').read_text()) != runtime
            or json.loads((bundle / 'public-environment.json').read_text()) != public_env
            or (bundle / 'runner.py').read_bytes() != runner_bytes):
        raise SystemExit('Existing bundle contents differ from observed inputs')
else:
    bundle.mkdir()
    write_new(bundle / 'identity.json', identity)
    write_new(bundle / 'manifest.json', before)
    write_new(bundle / 'runtime.json', runtime)
    write_new(bundle / 'public-environment.json', public_env)
    (bundle / 'runner.py').write_bytes(runner_bytes)

phpunit_args = ['phpunit', '--do-not-cache-result', '--colors=never', *([] if a.continue_on_defect else ['--stop-on-defect']),
                '--log-junit', str(run / 'junit.xml'), *a.files]
if a.filter:
    phpunit_args += ['--filter', a.filter]
code = 'require "vendor/autoload.php"; exit((new PHPUnit\\TextUI\\Application)->run(json_decode($argv[1], true, 32, JSON_THROW_ON_ERROR)));'
argv = ['php', '-d', 'memory_limit=512M', '-r', code, json.dumps(phpunit_args)]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
write_new(run / 'command.json', {'cwd': str(root), 'argv': argv, 'bundle': bundle.name,
    'source_before': state, 'selected_files': a.files, 'filter': a.filter, 'started_utc': started,
    'source_input_count': len(before), 'before_digest': identity['manifest_sha256'], 'before_git_equal': True,
    'input_scope': 'Tracked source plus actual directory inventory; undeclared files refused unread. bootstrap/cache and Python bytecode excluded.',
    'public_environment': public_env, 'timeout_seconds': a.timeout,
    'workload_scope': 'Root-serialized focused database workload; other component pure work may continue. No performance claim.',
    'overlays': []})
tick = time.monotonic()
def safe_signal_group(group, sig):
    try:
        os.killpg(group,sig)
    except ProcessLookupError:
        # The owned group can finish between its last observation and signalling.
        pass

def owned_group_members(group, birth):
    members=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():continue
        try:
            fields=(path/'stat').read_text().rsplit(')',1)[1].split()
            if int(fields[2])!=group:continue
            assert path.stat().st_uid==os.geteuid() and int(fields[3])==group
            start=fields[19]
            if int(path.name)==group:assert start==birth
            else:assert int(start)>=int(birth)
            members.append(dict(pid=int(path.name),state=fields[0],start_ticks=start))
        except FileNotFoundError:continue
    return members

observer = None
proc = None
process_exit = None
parent_birth = None
runner_timed_out = False
group_reconciliation = None
capture = dict(groups=[],errors=[])
with (run / 'log.txt').open('xb') as log:
    try:
        # Allocate and validate collector resources before creating any test process.
        observer = OwnedChildObserver(None, tmp / 'laravel-storage', root, run)
        observer.php_binary = runtime['php_binary']
        proc = subprocess.Popen(argv, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        parent_birth = OwnedChildObserver.process_start(proc.pid)
        observer.parent_pid = proc.pid
        while proc.poll() is None:
            if not observer.errors:
                try:
                    observer.poll()
                except Exception as error:
                    observer.errors.append(type(error).__name__ + ': ' + str(error))
            if time.monotonic() - tick > a.timeout:
                raise subprocess.TimeoutExpired(argv, a.timeout)
            time.sleep(.05)
        process_exit = proc.returncode
    except Exception as error:
        capture['errors'].append(type(error).__name__ + ': ' + str(error))
        log.write(('\nCollector/runner failure: '+type(error).__name__+': '+str(error)+'\n').encode())
        if proc is not None and proc.poll() is None:
            safe_signal_group(proc.pid,signal.SIGTERM)
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                safe_signal_group(proc.pid,signal.SIGKILL);proc.wait()
        if proc is not None:
            process_exit = proc.returncode
            runner_timed_out = isinstance(error,subprocess.TimeoutExpired)
    finally:
        if proc is not None and proc.poll() is None:
            safe_signal_group(proc.pid,signal.SIGTERM)
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                safe_signal_group(proc.pid,signal.SIGKILL);proc.wait()
            process_exit=proc.returncode
        if proc is not None and parent_birth is not None:
            # A reaped leader does not imply its original process group has no writers.
            try:
                members=owned_group_members(proc.pid,parent_birth)
                captured_births = {group['pid']:group['start_ticks'] for group in observer.groups.values()} if observer else {}
                for member in members:
                    if member['pid'] in captured_births:
                        assert member['start_ticks'] == captured_births[member['pid']]
                before_cleanup=members
                if any(member['state'] not in ['Z','X'] for member in members):
                    safe_signal_group(proc.pid,signal.SIGTERM)
                    for _ in range(100):
                        members=owned_group_members(proc.pid,parent_birth)
                        if all(member['state'] in ['Z','X'] for member in members):break
                        time.sleep(.05)
                    if any(member['state'] not in ['Z','X'] for member in members):
                        safe_signal_group(proc.pid,signal.SIGKILL)
                        for _ in range(100):
                            members=owned_group_members(proc.pid,parent_birth)
                            if all(member['state'] in ['Z','X'] for member in members):break
                            time.sleep(.05)
                assert all(member['state'] in ['Z','X'] for member in members)
                group_reconciliation=dict(original_group=proc.pid,parent_birth=parent_birth,captured_child_births=captured_births,before=before_cleanup,after=members,no_live_writers=True)
            except Exception as error:
                capture['errors'].append('Owned group reconciliation: '+type(error).__name__+': '+str(error))
        if observer is not None:
            try:
                captured = observer.finish()
                captured['errors'].extend(capture['errors'])
                capture = captured
            except Exception as error:
                capture['errors'].append('Final capture: '+type(error).__name__+': '+str(error))
            finally:
                observer.close()
write_new(run / 'owned-group-reconciliation.json', group_reconciliation)
write_new(run / 'child-capture.json', capture)
elapsed = time.monotonic() - tick
ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
(run / 'process.exit').write_text(str(process_exit) + '\n')
after, after_state, autoload_after = observed_inputs(), source_state(), autoload_inputs()
counts, junit_error = None, None
try:
    counts = reconcile_junit(run / 'junit.xml')
except Exception as error:
    junit_error = type(error).__name__ + ': ' + str(error)
capture_error = None
if process_exit == 0 and counts is not None:
    try:
        parent_cases = list(ET.parse(run / 'junit.xml').getroot().iter('testcase'))
        lifecycle_count = sum(c.get('classname', '').endswith('.FinalizationDatabaseLifecycleTest') for c in parent_cases)
        assert len(capture['groups']) == lifecycle_count and not capture['errors']
        expected_methods=['test_first_fixture_is_removed_even_when_its_body_throws','test_next_setup_recreates_the_complete_schema_without_previous_rows']
        datasets={
            'successful default connection uses the default view policy':(False,False,False),
            'throwing default connection removes requested views':(True,False,True),
            'successful named default connection removes requested views':(False,True,True),
            'throwing named default connection uses the default view policy':(True,True,False),
        }
        expected=[]
        for case in parent_cases:
            if case.get('classname','').endswith('.FinalizationDatabaseLifecycleTest'):
                matches=[signature for name,signature in datasets.items() if name in case.get('name','')]
                assert len(matches)==1
                expected.append(matches[0])
        actual=[]
        for group in capture['groups']:
            assert not group['replacements'] and group['directory_removed_by_parent'] and group['child_no_open_writers']
            assert set(group['files']) == {'junit.xml', 'events.log', 'receipt.jsonl'}
            child = ET.parse(run / group['files']['junit.xml']['archive_path']).getroot()
            cases=list(child.iter('testcase'))
            assert len(cases)==2 and [c.get('name') for c in cases]==expected_methods
            errors=[c.find('error') for c in cases if c.find('error') is not None]
            assert len(errors) in [0,1] and all(c.find('failure') is None and c.find('skipped') is None for c in cases)
            if errors:assert 'EXPECTED_LIFECYCLE_BODY_FAILURE' in ''.join(errors[0].itertext()) and cases[0].find('error') is not None
            receipts=[json.loads(line) for line in (run / group['files']['receipt.jsonl']['archive_path']).read_text().splitlines()]
            assert len(receipts)==2 and [r['test'] for r in receipts]==expected_methods
            assert receipts[0]['connection']==receipts[1]['connection'] and receipts[0]['views']==receipts[1]['views']
            alias=receipts[0]['connection']=='lifecycle_fixture'
            assert alias or receipts[0]['connection']==a.driver
            matching=[d for d in expected if d[0]==bool(errors) and d[1]==alias]
            assert len(matching)==1
            signature=matching[0]
            for receipt in receipts:
                assert [receipt['tables'],receipt['views'],receipt['migrated'],receipt['transaction_level'],receipt['callback_after_cleanup']]==[0,1 if a.driver=='mysql' and not signature[2] else 0,False,0,True]
            import re
            events=(run / group['files']['events.log']['archive_path']).read_text()
            warnings=r'^(?:Test Runner Triggered Warning|Test Triggered PHPUnit Warning) \(|^Test Triggered (?:PHP )?Warning \((?![^\r\n)]*, suppressed using operator(?:, ignored by baseline)?\) in )'
            assert re.search(warnings,events,re.M) is None
            actual.append(signature)
        assert sorted(actual)==sorted(expected)
    except Exception as error:
        capture_error = type(error).__name__ + ': ' + str(error)
source_equal = before == after
runner_after = digest(Path(__file__).read_bytes())
runner_unchanged = runner_after == digest(runner_bytes)
observer_unchanged = digest(Path(__file__).with_name('owned_child_observer_v4.py').read_bytes()) == runtime['observer_sha256']
source_head_unchanged = state['head'] == after_state['head']
source_status_unchanged = state['status'] == after_state['status']
verifier_exit = 0 if (process_exit == 0 and junit_error is None and capture_error is None and source_equal
    and autoload_before == autoload_after and runner_unchanged and observer_unchanged
    and source_head_unchanged and source_status_unchanged) else 1
result = {'process_exit': process_exit, 'runner_timed_out': runner_timed_out, 'verifier_exit': verifier_exit, 'junit': counts,
          'junit_error': junit_error, 'child_capture_error': capture_error, 'child_artifact_groups': len(capture['groups']), 'started_utc': started, 'ended_utc': ended, 'wall_seconds': elapsed,
          'source_after': after_state, 'bundle': bundle.name, 'source_input_count': len(after),
          'after_digest': digest(canonical(after)), 'source_unchanged': source_equal,
          'source_head_unchanged': source_head_unchanged, 'source_status_unchanged': source_status_unchanged,
          'runner_after_sha256': runner_after, 'runner_unchanged': runner_unchanged, 'observer_unchanged': observer_unchanged,
          'autoload_unchanged': autoload_before == autoload_after,
          'log_sha256': digest((run / 'log.txt').read_bytes())}
if not source_equal:
    result['source_delta'] = {k: [before.get(k), after.get(k)] for k in before.keys() | after.keys() if before.get(k) != after.get(k)}
if autoload_before != autoload_after:
    result['autoload_after'] = autoload_after
write_new(run / 'result.json', result)
print(json.dumps(result, indent=2))
raise SystemExit(verifier_exit)
