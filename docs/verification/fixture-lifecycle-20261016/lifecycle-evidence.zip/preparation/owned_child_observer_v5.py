"""Read-only capture of actual owned child artifacts through their original inodes."""
import hashlib
import os
from pathlib import Path
import re
import stat


class OwnedChildObserver:
    def __init__(self, parent_pid, storage, root, output):
        self.parent_pid = parent_pid
        self.php_binary = None
        self.storage = storage.resolve(strict=True)
        self.root = root.resolve(strict=True)
        self.output = output
        self.groups = {}
        self.errors = []
        self.max_groups = 4
        self.max_file_bytes = 8 * 1024 * 1024
        self.max_total_bytes = 64 * 1024 * 1024
        self.closed = False
        self.observations = []
        self.root_fds = []
        try:
            fd, identity = self.open_checked(self.storage, directory=True)
            self.root_fds.append((self.storage, fd, identity))
            for name in ['framework', 'testing']:
                fd, identity = self.open_checked(name, parent=fd, directory=True)
                path = self.root_fds[-1][0] / name
                self.root_fds.append((path, fd, identity))
            self.baseline = sorted(p.name for p in self.root_fds[-1][0].iterdir())
        except BaseException:
            self.close()
            raise

    def open_checked(self, name, parent=None, directory=False):
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | (os.O_DIRECTORY if directory else 0), dir_fd=parent)
        try:
            identity = os.fstat(fd)
            assert identity.st_uid == os.geteuid()
            assert (stat.S_ISDIR(identity.st_mode) if directory else stat.S_ISREG(identity.st_mode))
            assert directory or identity.st_size <= self.max_file_bytes
            return fd, identity
        except BaseException:
            os.close(fd)
            raise

    @staticmethod
    def process_start(pid):
        return (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()[19]

    def descendants(self, pid):
        # This execution kernel omits proc task/children; use actual stat PPIDs.
        edges = {}
        for path in Path('/proc').iterdir():
            if not path.name.isdigit():
                continue
            try:
                fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
                if path.stat().st_uid == os.geteuid():
                    edges.setdefault(int(fields[1]), []).append(int(path.name))
            except FileNotFoundError:
                continue
        result = []
        pending = [pid]
        while pending:
            children = edges.get(pending.pop(), [])
            result.extend(children)
            pending.extend(children)
        return result

    def poll(self):
        for path, _, original in self.root_fds:
            current = path.stat(follow_symlinks=False)
            assert stat.S_ISDIR(current.st_mode) and current.st_uid == original.st_uid
            assert (current.st_dev, current.st_ino) == (original.st_dev, original.st_ino)
        for pid in self.descendants(self.parent_pid):
            try:
                start_ticks = self.process_start(pid)
                argv = (Path('/proc') / str(pid) / 'cmdline').read_bytes().split(b'\0')
                if len(self.observations) < 32 and not any(v['pid'] == pid for v in self.observations):
                    self.observations.append(dict(pid=pid,start_ticks=start_ticks,argv0=argv[0].decode(errors='replace'),argc=len([x for x in argv if x])))
                if not any(str(self.root / 'tests/Support/FinalizationLifecycleFixture.php').encode() in arg for arg in argv):
                    continue
                args = [a.decode() for a in argv if a]
                if '--log-junit' not in args:
                    continue
                assert Path(args[0]).resolve() == Path(self.php_binary).resolve()
                assert str(self.root / 'vendor/bin/phpunit') in args
                assert (Path('/proc') / str(pid) / 'cwd').resolve() == self.root
                junit = Path(args[args.index('--log-junit') + 1])
                events = Path(args[args.index('--log-events-text') + 1])
                directory = junit.parent
                assert directory.name not in self.baseline
                assert directory.parent == self.storage / 'framework/testing'
                assert '--fail-on-phpunit-warning' in args
                assert args[args.index('--configuration') + 1] == str(self.root / 'phpunit.xml')
                assert re.fullmatch(r'lifecycle-[0-9a-f-]{36}', directory.name)
                assert junit.name == 'junit.xml' and events == directory / 'events.log'
                key = str(directory)
                if key not in self.groups:
                    assert len(self.groups) < self.max_groups, 'Child-directory capture bound exceeded'
                    fd, identity = self.open_checked(directory.name, parent=self.root_fds[-1][1], directory=True)
                    try:
                        assert self.process_start(pid) == start_ticks and pid in self.descendants(self.parent_pid)
                        current = directory.stat(follow_symlinks=False)
                        assert (current.st_dev,current.st_ino)==(identity.st_dev,identity.st_ino)
                    except BaseException:
                        os.close(fd)
                        raise
                    self.groups[key] = dict(fd=fd, dev=identity.st_dev, ino=identity.st_ino,
                                            pid=pid, start_ticks=start_ticks, acquired_monotonic=__import__('time').monotonic(), argv=args, files={}, replacements=[])
            except FileNotFoundError:
                continue
            except Exception as error:
                self.errors.append(type(error).__name__ + ': ' + str(error))
        for key, group in self.groups.items():
            directory = Path(key)
            try:
                identity = directory.stat(follow_symlinks=False)
                assert stat.S_ISDIR(identity.st_mode) and (identity.st_dev, identity.st_ino) == (group['dev'], group['ino'])
            except FileNotFoundError:
                continue
            except Exception as error:
                self.errors.append('Directory identity: ' + str(error))
                continue
            for name in ['junit.xml', 'events.log', 'receipt.jsonl']:
                try:
                    fd, identity = self.open_checked(name, parent=group['fd'])
                    if name in group['files']:
                        original = group['files'][name]
                        if (identity.st_dev, identity.st_ino) != (original['dev'], original['ino']):
                            group['replacements'].append(name)
                        os.close(fd)
                    else:
                        group['files'][name] = dict(fd=fd, dev=identity.st_dev, ino=identity.st_ino, uid=identity.st_uid, mode=identity.st_mode)
                except FileNotFoundError:
                    continue
                except Exception as error:
                    self.errors.append('File identity: ' + type(error).__name__ + ': ' + str(error))

    def finish(self):
        try:
            return self.collect_final_bytes()
        finally:
            self.close()

    def collect_final_bytes(self):
        records = []
        total_bytes = 0
        for key, group in self.groups.items():
            record = {k: group[k] for k in ['pid', 'start_ticks', 'acquired_monotonic', 'argv', 'dev', 'ino', 'replacements']}
            record['original_directory'] = key
            record['directory_removed_by_parent'] = not Path(key).exists()
            proc_path = Path('/proc') / str(group['pid'])
            record['child_process_gone'] = not proc_path.exists()
            record['child_no_open_writers'] = not proc_path.exists() or not list((proc_path / 'fd').iterdir())
            record['files'] = {}
            for name, captured in group['files'].items():
                final = os.fstat(captured['fd'])
                assert (final.st_dev, final.st_ino, final.st_uid, final.st_mode) == (captured['dev'], captured['ino'], captured['uid'], captured['mode'])
                assert final.st_size <= self.max_file_bytes and record['child_no_open_writers']
                assert final.st_nlink in [0,1]
                os.lseek(captured['fd'], 0, os.SEEK_SET)
                data = bytearray()
                while True:
                    chunk = os.read(captured['fd'], 65536)
                    if not chunk:
                        break
                    data.extend(chunk)
                    total_bytes += len(chunk)
                    assert len(data) <= self.max_file_bytes and total_bytes <= self.max_total_bytes
                after_read = os.fstat(captured['fd'])
                assert len(data) == final.st_size
                assert (after_read.st_dev,after_read.st_ino,after_read.st_uid,after_read.st_mode,after_read.st_size,after_read.st_mtime_ns,after_read.st_nlink)==(final.st_dev,final.st_ino,final.st_uid,final.st_mode,final.st_size,final.st_mtime_ns,final.st_nlink)
                target = self.output / 'child-originals' / Path(key).name / name
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as stream:
                    stream.write(data)
                record['files'][name] = dict(original_path=str(Path(key) / name), dev=captured['dev'],
                    ino=captured['ino'], archive_path=str(target.relative_to(self.output)),
                    final_metadata=dict(dev=final.st_dev, ino=final.st_ino, uid=final.st_uid, mode=final.st_mode, bytes=final.st_size, mtime_ns=final.st_mtime_ns, link_count=final.st_nlink), bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                    capture='Final bytes read from held read-only descriptor after parent completion; original inode, no pathname reconstruction.')
            records.append(record)
        return dict(groups=records, errors=self.errors,baseline_directory_inventory=self.baseline,observed_owned_children=self.observations,
                    bounds=dict(max_groups=self.max_groups,max_file_bytes=self.max_file_bytes,max_total_bytes=self.max_total_bytes), child_exit_evidence='Derived only from completed parent assertions; child stdout/stderr and independent wait status are not captured.')

    def close(self):
        if self.closed:
            return
        self.closed = True
        for group in self.groups.values():
            for captured in group['files'].values():
                try: os.close(captured['fd'])
                except OSError: pass
            try: os.close(group['fd'])
            except OSError: pass
        for _, fd, _ in reversed(self.root_fds):
            try: os.close(fd)
            except OSError: pass
