"""Read-only capture of actual owned child artifacts through their original inodes."""
import hashlib
import os
from pathlib import Path
import re
import stat


class OwnedChildObserver:
    def __init__(self, parent_pid, storage, root, output):
        self.parent_pid = parent_pid
        self.storage = storage.resolve(strict=True)
        self.root = root.resolve(strict=True)
        self.output = output
        self.groups = {}
        self.errors = []
        self.root_fds = []
        fd = os.open(self.storage, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        self.root_fds.append((self.storage, fd, os.fstat(fd)))
        for name in ['framework', 'testing']:
            fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            path = self.root_fds[-1][0] / name
            self.root_fds.append((path, fd, os.fstat(fd)))
        assert all(identity.st_uid == os.geteuid() for _, _, identity in self.root_fds)

    def descendants(self, pid):
        try:
            children = (Path('/proc') / str(pid) / 'task' / str(pid) / 'children').read_text().split()
        except FileNotFoundError:
            return []
        result = []
        for child in children:
            result.append(int(child))
            result.extend(self.descendants(int(child)))
        return result

    def poll(self):
        for path, _, original in self.root_fds:
            current = path.stat(follow_symlinks=False)
            assert stat.S_ISDIR(current.st_mode) and current.st_uid == original.st_uid
            assert (current.st_dev, current.st_ino) == (original.st_dev, original.st_ino)
        for pid in self.descendants(self.parent_pid):
            try:
                argv = (Path('/proc') / str(pid) / 'cmdline').read_bytes().split(b'\0')
                if str(self.root / 'tests/Support/FinalizationLifecycleFixture.php').encode() not in argv:
                    continue
                args = [a.decode() for a in argv if a]
                junit = Path(args[args.index('--log-junit') + 1])
                events = Path(args[args.index('--log-events-text') + 1])
                directory = junit.parent
                assert directory.parent == self.storage / 'framework/testing'
                assert re.fullmatch(r'lifecycle-[0-9a-f-]{36}', directory.name)
                assert junit.name == 'junit.xml' and events == directory / 'events.log'
                key = str(directory)
                if key not in self.groups:
                    fd = os.open(directory.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                                 dir_fd=self.root_fds[-1][1])
                    identity = os.fstat(fd)
                    assert identity.st_uid == os.geteuid()
                    self.groups[key] = dict(fd=fd, dev=identity.st_dev, ino=identity.st_ino,
                                            pid=pid, argv=args, files={}, replacements=[])
            except FileNotFoundError:
                continue
            except Exception as error:
                self.errors.append(type(error).__name__ + ': ' + str(error))
        for key, group in self.groups.items():
            directory = Path(key)
            try:
                identity = directory.stat(follow_symlinks=False)
                assert stat.S_ISDIR(identity.st_mode) and (identity.st_dev, identity.st_ino) == (group['dev'], group['ino'])
            except FileNotFoundError:
                continue
            except Exception as error:
                self.errors.append('Directory identity: ' + str(error))
                continue
            for name in ['junit.xml', 'events.log', 'receipt.jsonl']:
                try:
                    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=group['fd'])
                    identity = os.fstat(fd)
                    assert stat.S_ISREG(identity.st_mode) and identity.st_uid == os.geteuid()
                    if name in group['files']:
                        original = group['files'][name]
                        if (identity.st_dev, identity.st_ino) != (original['dev'], original['ino']):
                            group['replacements'].append(name)
                        os.close(fd)
                    else:
                        group['files'][name] = dict(fd=fd, dev=identity.st_dev, ino=identity.st_ino)
                except FileNotFoundError:
                    continue
                except Exception as error:
                    self.errors.append('File identity: ' + type(error).__name__ + ': ' + str(error))

    def finish(self):
        records = []
        for key, group in self.groups.items():
            record = {k: group[k] for k in ['pid', 'argv', 'dev', 'ino', 'replacements']}
            record['original_directory'] = key
            record['directory_removed_by_parent'] = not Path(key).exists()
            record['child_process_gone'] = not (Path('/proc') / str(group['pid'])).exists()
            record['files'] = {}
            for name, captured in group['files'].items():
                os.lseek(captured['fd'], 0, os.SEEK_SET)
                data = bytearray()
                while True:
                    chunk = os.read(captured['fd'], 65536)
                    if not chunk:
                        break
                    data.extend(chunk)
                target = self.output / 'child-originals' / Path(key).name / name
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as stream:
                    stream.write(data)
                record['files'][name] = dict(original_path=str(Path(key) / name), dev=captured['dev'],
                    ino=captured['ino'], archive_path=str(target.relative_to(self.output)),
                    bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                    capture='Final bytes read from held read-only descriptor after parent completion; original inode, no pathname reconstruction.')
                os.close(captured['fd'])
            os.close(group['fd'])
            records.append(record)
        for _, fd, _ in reversed(self.root_fds):
            os.close(fd)
        return dict(groups=records, errors=self.errors,
                    child_exit_evidence='Derived only from completed parent assertions; child stdout/stderr and independent wait status are not captured.')
