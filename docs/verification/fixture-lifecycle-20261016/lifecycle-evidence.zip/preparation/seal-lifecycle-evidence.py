import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path('/tmp/VA-Studio-staff-mfa-leftovers-20261015');runtime=Path('/tmp/fixture-lifecycle-evidence-20261016');packet=root/'docs/verification/fixture-lifecycle-20261016'
def sha(data):return hashlib.sha256(data).hexdigest()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':')).encode()
names=['native-default-calibration-original','sqlite-whole-compatibility-capture-original','sqlite-whole-compatibility-proc-stat-corrected-original','native-default-calibration-proc-stat-corrected-original','native-default-fixed420-calibration-original','native-whole-fixed420-lifecycle-original']
members={};private=[];outcomes=[];bundles=set()
for name in names:
 directory=runtime/name;command=json.loads((directory/'command.json').read_text());result=json.loads((directory/'result.json').read_text())
 assert all(result[k] for k in ['source_unchanged','source_head_unchanged','source_status_unchanged','runner_unchanged','observer_unchanged','autoload_unchanged'])
 for file in sorted(directory.rglob('*')):
  if not file.is_file():continue
  relative=str(file.relative_to(runtime))
  if result['verifier_exit']!=0 and (file.name in ['log.txt','junit.xml','events.log','receipt.jsonl']):
   private.append(dict(path=str(file),sha256=sha(file.read_bytes()),reason='Failed/interrupted original output privately retained; original parent counts/NULL-child evidence/recorder outcomes remain public.'))
  else:members[relative]=file.read_bytes()
 bundles.add(result['bundle']);outcomes.append(dict(name=name,source=command['source_before']['head'],result=result))
for name in sorted(bundles):
 d=runtime/name;i=json.loads((d/'identity.json').read_text());manifest=json.loads((d/'manifest.json').read_text());assert sha(canonical(manifest))==i['manifest_sha256'];assert sha((d/'runner.py').read_bytes())==i['runner_sha256']
 for file in sorted(d.iterdir()):members[str(file.relative_to(runtime))]=file.read_bytes()
for file in sorted(runtime.iterdir()):
 if file.is_file() and file.suffix in ['.py','.json','.txt','.log']:members['preparation/'+file.name]=file.read_bytes()
for name in ['initialize.json','server-start.json','schema-create.json','server-version.json','server-version-regex.json','server-final-shutdown.json','final-stop-reconciliation.json','server-stop-state-reconciled.json']:
 file=runtime/'mysql-standalone'/name;members['mysql-standalone/'+name]=file.read_bytes()
reviews=['fixture-lifecycle-source-and-observer-review-c96da8e2','fixture-lifecycle-observer-v2-review','fixture-lifecycle-observer-v3-carry-review','fixture-lifecycle-observer-v4-carry-review','fixture-lifecycle-observer-v5-carry-review','fixture-lifecycle-revised-budget-contract-review','f2-native-lifecycle-capture-contract-review','fixture-lifecycle-source-carry-572f078a']
for stem in reviews:
 for suffix in ['md','json']:
  source=Path('/tmp')/(stem+'-20261016.'+suffix)
  if not source.exists():assert stem=='f2-native-lifecycle-capture-contract-review' and suffix=='json';continue
  target=packet/('independent-'+stem+'.'+suffix);assert not target.exists();target.write_bytes(source.read_bytes())
source_bindings=[]
for head in sorted({d['source'] for d in outcomes}):
 for name in ['tests/Feature/FinalizationDatabaseLifecycleTest.php','tests/Support/FinalizationLifecycleFixture.php','tests/Support/FinalizationDatabaseMigrations.php','tests/TestCase.php']:
  data=subprocess.check_output(['git','show',head+':'+name],cwd=root);archive_name='source/'+head+'/'+name;members[archive_name]=data;source_bindings.append(dict(head=head,path=name,sha256=sha(data),archive_name=archive_name))
frozen_paths=json.loads((root/'docs/verification/fixture-admission-20261015/owned-file-and-local-index.json').read_text())['frozen_members_and_manifests_equal_pr130'];frozen={}
for name in frozen_paths:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show','3b90ce476d4480de850e849d19dfd0a5b40d6835:'+name],cwd=root);frozen[name]=sha(data)
expected={
 'native-default-calibration-original':(-15,1,None),
 'sqlite-whole-compatibility-capture-original':(0,1,12),
 'sqlite-whole-compatibility-proc-stat-corrected-original':(0,0,12),
 'native-default-calibration-proc-stat-corrected-original':(2,1,1),
 'native-default-fixed420-calibration-original':(0,0,1),
 'native-whole-fixed420-lifecycle-original':(0,0,4),
}
for outcome in outcomes:
 d=outcome['result'];assert (d['process_exit'],d['verifier_exit'],d['junit']['tests'] if d['junit'] else None)==expected[outcome['name']]
 if d['verifier_exit']==0:assert d['junit']['failures']==d['junit']['errors']==d['junit']['skipped']==0 and d['child_capture_error'] is None
archive=packet/'lifecycle-evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for name,data in sorted(members.items()):z.writestr(name,data)
index=dict(archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,members=[dict(name=n,sha256=sha(b)) for n,b in sorted(members.items())],original_php_invocations=outcomes,bundles=sorted(bundles),private_originals=private,source_bindings=source_bindings,frozen_paths_equal_pr131=frozen,limits='Six separate parent invocations, children NOT extra acceptance cases. Native300failed1/2/E1+interrupted52s-15/NULL and SQLite-parent12/181recorder1 remain nonpassing original outcomes. Corrected SQLite12/181 executedc96; literal-only MySQL420 head572 carry separately proven. Child exits derive parent assertions, not independent raw exit/stdout/stderr capture. Exact whole native4 passes only its source/runtime, not fullF2/25counterparts/rawworkers/performance/host/provider/activation/release. No Foundation/GitLab dispatch.')
with (packet/'lifecycle-index.json').open('x') as f:json.dump(index,f,indent=2);f.write('\n')
print(json.dumps(dict(members=len(members),invocations=len(outcomes),private_originals=len(private),archive_sha256=index['archive_sha256']),indent=2))
