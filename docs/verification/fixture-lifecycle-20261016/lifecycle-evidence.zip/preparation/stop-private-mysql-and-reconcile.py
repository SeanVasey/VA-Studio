from pathlib import Path
import datetime,hashlib,json,subprocess,time
r=Path('/tmp/fixture-lifecycle-evidence-20261016');out=r/'mysql-standalone';socket=Path('/tmp/va-studio-fixture-lifecycle-mysql-socket-20261016/mysql.sock');data=Path('/tmp/va-studio-fixture-lifecycle-mysql-data-20261016')
pid=int((out/'mysqld.pid').read_text());argv=(Path('/proc')/str(pid)/'cmdline').read_bytes().split(b'\0')
assert ('--datadir='+str(data)).encode() in argv and b'--port=33525' in argv
start=time.monotonic();result=subprocess.run(['python3',str(r/'prepare-private-mysql.py'),'--stage','stop']);result.check_returncode()
for _ in range(450):
 if not socket.exists() and not (Path('/proc')/str(pid)).exists():break
 time.sleep(.1)
log=(out/'server.log').read_bytes();tail=log.rsplit(b'MySQL Server - start.',1)[1]
record=dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),shutdown_command_exit=result.returncode,owned_pid=pid,socket_gone=not socket.exists(),pid_gone=not (Path('/proc')/str(pid)).exists(),normal_current_start_shutdown_logged=b'Shutdown complete' in tail and b'MySQL Server - end.' in tail,server_log_private_sha256=hashlib.sha256(log).hexdigest(),datadir_retained=str(data),bounded_reconciliation_seconds=45,actual_wall_seconds=time.monotonic()-start)
with (out/'final-stop-reconciliation.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
assert record['socket_gone'] and record['pid_gone'] and record['normal_current_start_shutdown_logged'] and data.is_dir()
print(json.dumps(record,indent=2))
