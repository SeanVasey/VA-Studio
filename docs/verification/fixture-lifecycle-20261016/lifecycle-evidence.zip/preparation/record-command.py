import argparse,datetime,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('argv',nargs=argparse.REMAINDER);a=p.parse_args();argv=a.argv[1:] if a.argv[0]=='--' else a.argv
root=Path('/tmp/VA-Studio-staff-mfa-leftovers-20261015');out=Path('/tmp/fixture-lifecycle-evidence-20261016');target=out/(a.name+'.json');assert not target.exists()
def state():return dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True))
before=state();started=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=root,capture_output=True,text=True);after=state();log=(r.stdout+r.stderr).encode();(out/(a.name+'.log')).write_bytes(log)
record=dict(argv=argv,cwd=str(root),source_before=before,source_after=after,started_utc=started,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),process_exit=r.returncode,source_unchanged=before==after,log_sha256=hashlib.sha256(log).hexdigest())
with target.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record,indent=2));raise SystemExit(r.returncode if before==after else 1)
