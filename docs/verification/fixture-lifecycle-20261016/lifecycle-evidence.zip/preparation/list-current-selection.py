import json,subprocess
from pathlib import Path
root=Path('/tmp/VA-Studio-staff-mfa-leftovers-20261015');out=Path('/tmp/fixture-lifecycle-evidence-20261016');filter='test_cleanup_and_the_next_setup_remain_isolated.*successful default connection uses the default view policy'
code='require "vendor/autoload.php"; exit((new PHPUnit\\TextUI\\Application)->run(json_decode($argv[1], true, 32, JSON_THROW_ON_ERROR)));'
for name,args,count in [('native-calibration-exact-list',['phpunit','--list-tests','--filter',filter,'tests/Feature/FinalizationDatabaseLifecycleTest.php'],1),('sqlite-compatibility-whole-list',['phpunit','--list-tests','tests/Feature/OperatorMfaTest.php','tests/Feature/StagingOperatorMfaTest.php','tests/Feature/FinalizationDatabaseLifecycleTest.php'],12)]:
 command=['python3',str(out/'record-command.py'),'--name',name,'--','php','-r',code,json.dumps(args)];subprocess.run(command,cwd=root,check=True);lines=[l for l in (out/(name+'.log')).read_text().splitlines() if l.lstrip().startswith('- ')];assert len(lines)==count;print(name,'actualListed',len(lines));print('\n'.join(lines))
(out/'native-calibration-exact-filter.txt').write_text(filter+'\n')
