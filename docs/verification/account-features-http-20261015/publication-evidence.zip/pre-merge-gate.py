import json,subprocess,datetime
from pathlib import Path
root=Path('/workspace/VA-Studio-tax-v2-committed-read')
out=Path('/workspace/runtime/account-features-http-publication-20261015')
head='0902be9ed5c3202444521d697f79ce8641f1fa89'
def record(name):
 d=json.loads((out/(name+'.json')).read_text());assert d['exit']==0;return json.loads(d['stdout'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
run=record('preflight-final');assert run['headSha']==head and run['databaseId']==38799654906 and run['status']=='completed' and run['conclusion']=='success'
expected={'scope':'success','frontend':'success','backend-quality':'success','documentation':'skipped','Development preflight result':'success'}
assert {j['name']:j['conclusion'] for j in run['jobs']}==expected
pr=record('final-review-check-inventory')['data']['repository']['pullRequest']
assert pr['number']==127 and pr['headRefOid']==head and pr['baseRefOid']=='9cfe3a618e19557b95828d35c52a0e4d3622b44a'
assert not pr['isDraft'] and pr['mergeable']=='MERGEABLE' and pr['mergeStateStatus']=='CLEAN'
for k in ['reviews','reviewThreads']:assert not pr[k]['pageInfo']['hasNextPage']
assert all(r['state'] in ['COMMENTED','APPROVED','DISMISSED'] for r in pr['reviews']['nodes'])
assert all(t['isResolved'] and not t['comments']['pageInfo']['hasNextPage'] for t in pr['reviewThreads']['nodes'])
contexts=pr['statusCheckRollup']['contexts'];assert not contexts['pageInfo']['hasNextPage']
for n in contexts['nodes']:
 if 'name' in n:
  assert n['status']=='COMPLETED' and n['conclusion'] in ['SUCCESS','SKIPPED','NEUTRAL']
 else:assert n['state']=='SUCCESS'
assert record('applicable-rules-read')==[]
assert record('branch-protection-read')['data']['repository']['defaultBranchRef']['branchProtectionRule'] is None
required=json.loads((out/'supported-required-checks-read.json').read_text());assert required['exit']==1 and 'no required checks reported' in required['stderr'].lower()
carry=json.loads(Path('/workspace/runtime/account-features-http-publication-carry-0902be9e-20261015.json').read_text())
assert carry['reviewed_head']==head and carry['decision']=='APPROVE DOCUMENTATION-ONLY PUBLICATION CARRY'
assert carry['open_p0']==carry['open_p1']==0 and carry['required_corrections']==[]
receipt={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_head':head,'preflight_run':run['databaseId'],'preflight_jobs':expected,'review_count':len(pr['reviews']['nodes']),'thread_count':len(pr['reviewThreads']['nodes']),'all_threads_resolved':True,'check_context_count':len(contexts['nodes']),'pagination_complete':True,'mergeable':pr['mergeable'],'merge_state':pr['mergeStateStatus'],'rules':[],'branch_protection':None,'supported_required_check_diagnostic':required['stderr'].strip(),'independent_publication_carry':'APPROVE DOCUMENTATION-ONLY PUBLICATION CARRY','scope':'Focused development gate only; readiness cancellation artifact retained; no settings change or bypass.'}
p=out/'pre-merge-gate-0902be9e.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
