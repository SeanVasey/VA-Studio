import json,subprocess,datetime
from pathlib import Path
root=Path('/workspace/VA-Studio-tax-v2-committed-read')
out=Path('/workspace/runtime/account-features-http-publication-20261015')
head='483f037a6b4c35ef29b89adf4b342ba8dc823eab'
def record(name):
 d=json.loads((out/(name+'.json')).read_text());assert d['exit']==0;return json.loads(d['stdout'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
run=record('corrected-preflight-final');assert run['headSha']==head and run['databaseId']==json.loads((out/'corrected-run-identity.json').read_text())['databaseId'] and run['status']=='completed' and run['conclusion']=='success'
expected={'scope':'success','frontend':'success','backend-quality':'success','documentation':'skipped','Development preflight result':'success'}
assert {j['name']:j['conclusion'] for j in run['jobs']}==expected
pr=record('post-p2-final-review-check-inventory')['data']['repository']['pullRequest']
assert pr['number']==127 and pr['headRefOid']==head and pr['baseRefOid']=='9cfe3a618e19557b95828d35c52a0e4d3622b44a'
assert not pr['isDraft'] and pr['mergeable']=='MERGEABLE' and pr['mergeStateStatus']=='CLEAN'
for k in ['reviews','reviewThreads']:assert not pr[k]['pageInfo']['hasNextPage']
assert all(r['state'] in ['COMMENTED','APPROVED','DISMISSED'] for r in pr['reviews']['nodes'])
triage=json.loads(Path('/workspace/runtime/account-features-http-late-p2-triage-483f037a-20261015.json').read_text())
assert triage['reviewed_head']==head and triage['open_p0']==triage['open_p1']==0 and triage['development_merge_permitted_with_conditions'] is True
assert {(f['id'],f['severity']) for f in triage['findings']}=={('r4287886519','P2'),('r4287886535','P2')}
deferred=json.loads((out/'late-p2-deferred-record-original.json').read_text())
assert deferred['publication_head']==head
accepted={f['original_url']:f for f in deferred['findings']}
assert set(accepted)=={'https://github.com/SeanVasey/VA-Studio/pull/127#discussion_r4287886519','https://github.com/SeanVasey/VA-Studio/pull/127#discussion_r4287886535'}
unresolved=[]
for thread in pr['reviewThreads']['nodes']:
 assert not thread['comments']['pageInfo']['hasNextPage']
 if thread['isResolved']:continue
 comments=thread['comments']['nodes']; original=comments[0]
 assert original['url'] in accepted and 'P2 Badge' in original['body']
 reply=accepted[original['url']]
 assert len([c for c in comments if c['url']==reply['reply_url'] and c['body']==reply['reply_body'] and c['author']['login']==reply['reply_author']])==1
 unresolved.append(original['url'])
assert set(unresolved)==set(accepted)

contexts=pr['statusCheckRollup']['contexts'];assert not contexts['pageInfo']['hasNextPage']
for n in contexts['nodes']:
 if 'name' in n:
  assert n['status']=='COMPLETED' and n['conclusion'] in ['SUCCESS','SKIPPED','NEUTRAL']
 else:assert n['state']=='SUCCESS'
assert record('corrected-final-rules-read')==[]
assert record('corrected-final-protection-read')['data']['repository']['defaultBranchRef']['branchProtectionRule'] is None
required=json.loads((out/'corrected-final-required-checks-read.json').read_text());assert required['exit']==1 and 'no required checks reported' in required['stderr'].lower()
carry=json.loads(Path('/workspace/runtime/account-features-http-publication-carry-483f037a-20261015.json').read_text())
assert carry['reviewed_publication_head']==head and carry['decision']=='APPROVE FINAL DOCUMENTATION-ONLY PUBLICATION CARRY'
assert carry['open_p0']==carry['open_p1']==0 and carry['required_corrections']==[]
receipt={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_head':head,'preflight_run':run['databaseId'],'preflight_jobs':expected,'review_count':len(pr['reviews']['nodes']),'thread_count':len(pr['reviewThreads']['nodes']),'all_threads_resolved':False,'unresolved_deferred_p2_count':len(unresolved),'deferred_p2_urls':unresolved,'deferral_policy':'Sean freeze-and-batch; independent specific P2 triage, one reply each and actual-merge ledger registration required','check_context_count':len(contexts['nodes']),'pagination_complete':True,'mergeable':pr['mergeable'],'merge_state':pr['mergeStateStatus'],'rules':[],'branch_protection':None,'supported_required_check_diagnostic':required['stderr'].strip(),'independent_publication_carry':'APPROVE FINAL DOCUMENTATION-ONLY PUBLICATION CARRY','scope':'Focused development gate only; readiness cancellation artifact retained; no settings change or bypass.'}
p=out/'pre-merge-gate-483f037a.json';assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
